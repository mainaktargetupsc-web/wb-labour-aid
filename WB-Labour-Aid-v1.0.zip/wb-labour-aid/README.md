# পশ্চিমবঙ্গ শ্রম সহায়িকা · WB Labour Aid

শ্রমিক, নিয়োগকর্তা (এইচআর) ও শ্রম আধিকারিকদের জন্য দ্বিভাষিক (বাংলা + English) ওয়েব অ্যাপ — পূর্বতন শ্রম আইন, চারটি নতুন শ্রম কোড, প্রশিক্ষণ, সরকারি আদেশ, আলোচনা, ফর্ম ও বিধিপালন নির্দেশিকা।

A bilingual (Bengali + English) web app for workers, employers (HR) and Labour Officers in West Bengal: erstwhile labour laws, the four Labour Codes, training, Govt orders, discussions, forms and compliance guidance.

---

## ১. বৈশিষ্ট্য · Features

| ভূমিকা · Role | যা দেখতে পান · Sections |
|---|---|
| অতিথি / সাধারণ নাগরিক · Guest / Public | হোম, পূর্বতন আইন, নতুন কোড, আলোচনা ও সরকারি আদেশ, যোগাযোগ (i, ii, iii, v, viii) |
| এইচআর – কোম্পানি · HR – Company | উপরের সব + প্রশিক্ষণ, ফর্ম, বিধিপালন নির্দেশিকা, এইচআর-এর দায়িত্ব (x বাদে সব) |
| শ্রম আধিকারিক · Labour Officer | সব ১০টি বিভাগ; সরকারি আদেশ পোস্ট ও আলোচনা মডারেট করতে পারেন |
| অ্যাডমিন · Administrator | সব বিভাগ + প্রশাসন: আধিকারিক অনুমোদন, পাসওয়ার্ড রিসেট, পরিসংখ্যান |

- শ্রম আধিকারিক হিসেবে নিবন্ধনের পর **অ্যাডমিন অনুমোদন না দেওয়া পর্যন্ত** তিনি সাধারণ ব্যবহারকারী হিসেবে গণ্য হন। Officer accounts stay Public until the administrator approves them.
- ফোনে অ্যাপ হিসেবে ইনস্টল করা যায় (PWA); রেফারেন্স পেজগুলি অফলাইনেও খোলে। Installable on phones; reference pages open offline.
- লেখার আকার বাড়ানো-কমানো (A− A A+), কিবোর্ড দিয়ে চালানো যায়, স্ক্রিন-রিডারের জন্য `lang` চিহ্ন। Text resize, keyboard navigation, language tags for screen readers.
- বাইরের কোনো সার্ভিস/CDN লাগে না — ফন্টসহ সব কিছু অ্যাপের ভেতরে। No external services or CDNs; fonts are self-hosted.

## ২. প্রয়োজনীয়তা · Requirements

- PHP **8.1 বা তার পরের** সংস্করণ, `pdo_mysql` (অথবা পরীক্ষার জন্য `pdo_sqlite`) এক্সটেনশনসহ
- MySQL 5.7+ / MariaDB 10.4+
- Apache (mod_rewrite লাগে না) অথবা Nginx + PHP-FPM
- HTTPS সার্টিফিকেট (প্রোডাকশনে বাধ্যতামূলক — HTTPS ছাড়া ফোনে ইনস্টল হবে না)

## ৩. ফোল্ডার · Folder layout

```
wb-labour-aid/
├── public/            ← ওয়েব রুট (Document root) — শুধু এই ফোল্ডারটি ওয়েবে খোলা থাকবে
│   ├── index.html     অ্যাপ
│   ├── api.php        সার্ভার API
│   ├── app.js         অ্যাপের লজিক
│   ├── content.js     ★ সব লেখা (বাংলা + English) — লেখা বদলাতে শুধু এটি সম্পাদনা করুন
│   ├── config.js      ডেমো মোড চালু/বন্ধ
│   ├── styles.css, sw.js, manifest.webmanifest, fonts/, icons/
├── app/               ← ওয়েবের বাইরে রাখুন (কনফিগ ও ডাটাবেস কোড)
│   ├── config.sample.php
│   ├── install.php    এককালীন ইনস্টলার
│   ├── lib.php
│   └── schema.mysql.sql, schema.sqlite.sql
└── data/              ← শুধু SQLite ব্যবহার করলে
```

## ৪. ইনস্টল · Installation (MySQL)

**ধাপ ১ — ডাটাবেস তৈরি করুন · Create the database**

```sql
CREATE DATABASE wblabouraid CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'wblabouraid'@'localhost' IDENTIFIED BY 'একটি-শক্ত-পাসওয়ার্ড';
GRANT ALL PRIVILEGES ON wblabouraid.* TO 'wblabouraid'@'localhost';
FLUSH PRIVILEGES;
```

**ধাপ ২ — ফাইল কপি করুন · Copy the files** সার্ভারে, যেমন `/var/www/wb-labour-aid/`। ওয়েব সার্ভারের Document root হবে `public/` ফোল্ডার।

**ধাপ ৩ — কনফিগারেশন · Configure**

```bash
cd /var/www/wb-labour-aid
cp app/config.sample.php app/config.php
nano app/config.php      # driver => 'mysql', ডাটাবেসের নাম/ইউজার/পাসওয়ার্ড, 'https' => true
```

**ধাপ ৪ — ইনস্টলার চালান · Run the installer** (টেবিল ও প্রথম অ্যাডমিন অ্যাকাউন্ট তৈরি করে)

```bash
php app/install.php
```

নাম, ইমেল, মোবাইল ও পাসওয়ার্ড (অন্তত ১০ অক্ষর) চাইবে। এই অ্যাকাউন্ট দিয়ে সাইন ইন করলে "প্রশাসন" ট্যাব দেখা যাবে।

**ধাপ ৫ — অনুমতি · Permissions**

```bash
chown -R root:www-data /var/www/wb-labour-aid
chmod 640 app/config.php
```

### Nginx উদাহরণ · Example

```nginx
server {
    listen 443 ssl http2;
    server_name labouraid.wb.gov.in;           # আপনার ডোমেইন
    root /var/www/wb-labour-aid/public;
    index index.html;
    ssl_certificate     /etc/ssl/certs/site.crt;
    ssl_certificate_key /etc/ssl/private/site.key;

    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options SAMEORIGIN always;
    add_header Content-Security-Policy "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'self'" always;

    location = /api.php {
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root/api.php;
        fastcgi_pass unix:/run/php/php8.2-fpm.sock;
    }
    location ~ \.php$ { return 404; }
    location ~* \.(woff2|png)$ { expires 30d; }
    location = /sw.js { add_header Cache-Control "no-cache"; }
}
```

Apache-এর জন্য `public/.htaccess` ও `app/.htaccess` ফাইল আগে থেকেই দেওয়া আছে।

### শুধু public_html থাকলে · Shared hosting

`public/`-এর ভেতরের সব কিছু `public_html/`-এ রাখুন এবং `app/` ফোল্ডারটি `public_html`-এর **বাইরে** (এক ধাপ উপরে) রাখুন। ফোল্ডারের জায়গা আলাদা হলে `public/api.php`-এর `$APP_DIR` লাইনটি বদলান।

### দ্রুত পরীক্ষা · Quick local test (SQLite)

```bash
cp app/config.sample.php app/config.php      # driver = sqlite (ডিফল্ট)
php app/install.php
php -S localhost:8000 -t public
# ব্রাউজারে খুলুন: http://localhost:8000
```

## ৫. দৈনন্দিন কাজ · Day-to-day administration

- **আধিকারিক অনুমোদন:** অ্যাডমিন হিসেবে সাইন ইন → "প্রশাসন" → "অপেক্ষমাণ" তালিকা → যাচাই করে "অনুমোদন"। প্রয়োজনে "প্রত্যাহার" করা যায়।
- **পাসওয়ার্ড ভুলে গেলে:** "প্রশাসন" → ব্যবহারকারী → "পাসওয়ার্ড রিসেট" (দুবার চাপুন)। যে অস্থায়ী পাসওয়ার্ড দেখাবে তা ব্যবহারকারীকে আলাদাভাবে জানান; তিনি "অ্যাকাউন্ট" থেকে বদলে নেবেন।
- **লেখা বদলানো:** `public/content.js` সম্পাদনা করুন। প্রতিটি অংশ `["বাংলা", "English"]` আকারে আছে। হেল্পলাইন নম্বর `contact.helpline`-এ বসান।
- **সরকারি আদেশ:** অনুমোদিত আধিকারিক "আলোচনা ও সরকারি আদেশ" থেকে PDF লিংকসহ পোস্ট করবেন।
- **লেখা আপডেটের পর:** `public/sw.js`-এ `CACHE = "wbla-v1"` সংখ্যাটি বাড়ান (v2, v3…) যাতে ফোনে পুরোনো কপি না থাকে।

## ৬. ব্যাকআপ ও নিরাপত্তা · Backup & security

```bash
mysqldump -u wblabouraid -p wblabouraid > backup-$(date +%F).sql     # প্রতিদিন ব্যাকআপ
```

- পাসওয়ার্ড bcrypt দিয়ে হ্যাশ করা থাকে; সাধারণ লেখায় কোথাও রাখা হয় না।
- প্রতিটি পরিবর্তনের অনুরোধে CSRF টোকেন যাচাই হয়; সেশন কুকি HttpOnly ও SameSite।
- একই IP থেকে ১৫ মিনিটে ১০ বার ভুল পাসওয়ার্ড দিলে লগইন সাময়িক বন্ধ থাকে।
- সব ইনপুট সার্ভারে যাচাই হয়; সব ডাটাবেস কোয়েরি prepared statement।
- `app/` ও `data/` কখনো ওয়েবে খোলা রাখবেন না।

## ৭. ডেমো মোড · Demo mode

`public/config.js`-এ `window.WBLA_DEMO = true` করলে সার্ভার বা ডাটাবেস ছাড়াই অ্যাপ চলে (তথ্য প্রতিটি ডিভাইসের ব্রাউজারে থাকে)। শুধু দেখানো/প্রশিক্ষণের জন্য — যেকোনো স্ট্যাটিক হোস্টিংয়ে (যেমন GitHub Pages) চালানো যায়। `api.php` লাগে না।

## ৮. ভবিষ্যতে যোগ করা যায় · Possible additions

- NIC SMS গেটওয়ে দিয়ে মোবাইল OTP লগইন ও পাসওয়ার্ড রিসেট
- নতুন সরকারি আদেশ প্রকাশ হলে ইমেল/SMS বিজ্ঞপ্তি
- ফর্ম ও রেজিস্টারের সরকারি PDF আপলোড
- Play Store / App Store-এ অ্যাপ — নিচে দেখুন

## ৯. Android APK ও Play Store · Android app

সার্ভারে HTTPS-সহ অ্যাপ চালু হলে, বিনামূল্যে Android অ্যাপ (APK/AAB) বানানো যায় —
Once the site is live over HTTPS, build the Android app free:

1. https://www.pwabuilder.com খুলে সাইটের ঠিকানা দিন (যেমন `https://labouraid.wb.gov.in/`) → **Start**
2. **Package for stores → Android → Generate Package**
3. ডাউনলোড হওয়া zip-এ `.apk` (সরাসরি ইনস্টল) ও `.aab` (Play Store-এর জন্য) থাকবে, সঙ্গে **signing key** — এটি নিরাপদে রাখুন; প্রতিটি আপডেটে একই key লাগবে।
4. Play Store-এ প্রকাশ: দপ্তরের নিজস্ব Google Play Console অ্যাকাউন্ট (একবার $25) থেকে `.aab` আপলোড করুন, এবং zip-এর `assetlinks.json` ফাইলটি সাইটের `public/.well-known/assetlinks.json`-এ রাখুন (না রাখলে অ্যাপে ব্রাউজারের ঠিকানা-বার দেখাবে)।
5. iPhone: App Store-এর জন্য Apple Developer অ্যাকাউন্ট (বছরে $99) ও Mac লাগে; ততদিন Safari → Share → **Add to Home Screen**।

অ্যাপ প্রকাশকের নাম দপ্তরের হওয়া উচিত, তাই স্টোর অ্যাকাউন্ট দপ্তরের নামে খোলাই নিয়ম। The store accounts should be opened in the Department's name.

---

এটি একটি তথ্যমূলক সহায়িকা; আইনি ব্যাখ্যার জন্য সর্বদা সরকারি বিজ্ঞপ্তি দেখুন।
This is an information guide; always refer to official notifications for legal interpretation.
