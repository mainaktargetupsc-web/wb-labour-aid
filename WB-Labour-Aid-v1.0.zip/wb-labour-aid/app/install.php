<?php
/*
 * WB Labour Aid — installer (run once from the command line)
 *
 *   php app/install.php
 *
 * Creates the database tables and the first administrator account.
 * ডাটাবেস টেবিল ও প্রথম অ্যাডমিন অ্যাকাউন্ট তৈরি করে। কমান্ড লাইন থেকে একবার চালান।
 *
 * Non-interactive use:
 *   php app/install.php --name="Admin Name" --email=admin@example.gov.in --mobile=9800000000 --password="..."
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

require __DIR__ . '/lib.php';

if (!is_file(__DIR__ . '/config.php')) {
    fwrite(STDERR, "app/config.php not found. Copy app/config.sample.php to app/config.php and edit it first.\n");
    exit(1);
}

$cfg = config();
$schemaFile = __DIR__ . ($cfg['db']['driver'] === 'mysql' ? '/schema.mysql.sql' : '/schema.sqlite.sql');
$sql = preg_replace('/^--.*$/m', '', file_get_contents($schemaFile));
foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
    db()->exec($stmt);
}
echo "✓ Database tables ready (" . $cfg['db']['driver'] . ")\n";

$admins = (int)q("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
if ($admins > 0) {
    echo "✓ An administrator already exists — nothing else to do.\n";
    exit(0);
}

$opts = getopt('', ['name:', 'email:', 'mobile:', 'password:']);
function ask(string $label, ?string $given, bool $hidden = false): string {
    if ($given !== null && $given !== '') return $given;
    echo $label . ': ';
    if ($hidden && stripos(PHP_OS, 'WIN') === false) system('stty -echo');
    $v = trim((string)fgets(STDIN));
    if ($hidden && stripos(PHP_OS, 'WIN') === false) { system('stty echo'); echo "\n"; }
    return $v;
}

echo "\nCreate the administrator account / অ্যাডমিন অ্যাকাউন্ট তৈরি করুন\n";
$name   = ask('Full name', $opts['name'] ?? null);
$email  = strtolower(ask('Email', $opts['email'] ?? null));
$mobile = ask('Mobile (10 digits)', $opts['mobile'] ?? null);
$pass   = ask('Password (min 10 characters)', $opts['password'] ?? null, true);

if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^[6-9]\d{9}$/', $mobile) || strlen($pass) < 10) {
    fwrite(STDERR, "Invalid details: check name, email, 10-digit mobile and a password of at least 10 characters.\n");
    exit(1);
}

q('INSERT INTO users (name, email, mobile, password_hash, role, officer_status, district, org, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
  [$name, $email, $mobile, password_hash($pass, PASSWORD_DEFAULT), 'admin', null, 'Kolkata', 'Labour Department, Govt. of West Bengal', now()]);

echo "✓ Administrator created: $email\n";
echo "Open the site and sign in with this email to approve Labour Officers.\n";
