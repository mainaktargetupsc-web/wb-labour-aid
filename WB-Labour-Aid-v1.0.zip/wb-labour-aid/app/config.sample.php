<?php
/*
 * WB Labour Aid — configuration
 * Copy this file to config.php and fill in the values.
 * এই ফাইলটি config.php নামে কপি করে মানগুলি পূরণ করুন।
 */
return [
    'db' => [
        // 'mysql' for production servers, 'sqlite' for a quick test
        // প্রোডাকশনে 'mysql', দ্রুত পরীক্ষার জন্য 'sqlite'
        'driver'      => 'sqlite',

        // SQLite file (only used when driver = sqlite). Keep it outside the web root.
        'sqlite_path' => __DIR__ . '/../data/wblabouraid.sqlite',

        // MySQL / MariaDB (used when driver = mysql)
        'host'        => '127.0.0.1',
        'port'        => 3306,
        'name'        => 'wblabouraid',
        'user'        => 'wblabouraid',
        'pass'        => 'CHANGE_ME',
    ],

    // Set true when the site is served over HTTPS (it should be in production)
    // সাইট HTTPS-এ চললে true করুন (প্রোডাকশনে অবশ্যই HTTPS ব্যবহার করুন)
    'https' => false,

    // Session lifetime in seconds (default 7 days)
    'session_lifetime' => 604800,
];
