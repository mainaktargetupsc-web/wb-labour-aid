<?php
/* WB Labour Aid — shared helpers (database, session, auth, JSON). */
declare(strict_types=1);

const ROLES_SELF  = ['public', 'hr', 'officer'];            // roles a person can register as
const ORDER_KINDS = ['Notification', 'Order', 'Circular', 'Gazette', 'Notice'];
const MAX_TRAINING_MODULES = 50;

function config(): array {
    static $cfg = null;
    if ($cfg === null) {
        $file = __DIR__ . '/config.php';
        if (!is_file($file)) {
            json_out(['error' => 'অ্যাপটি এখনও ইনস্টল করা হয়নি। The app is not installed yet (app/config.php missing).'], 503);
        }
        $cfg = require $file;
    }
    return $cfg;
}

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = config()['db'];
    if ($c['driver'] === 'mysql') {
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $c['host'], $c['port'], $c['name']);
        $pdo = new PDO($dsn, $c['user'], $c['pass']);
    } else {
        $dir = dirname($c['sqlite_path']);
        if (!is_dir($dir)) mkdir($dir, 0750, true);
        $pdo = new PDO('sqlite:' . $c['sqlite_path']);
        $pdo->exec('PRAGMA journal_mode = WAL');
    }
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    return $pdo;
}

function q(string $sql, array $params = []): PDOStatement {
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function now(): string { return gmdate('Y-m-d H:i:s'); }
function iso(?string $t): ?string { return $t ? str_replace(' ', 'T', $t) . 'Z' : null; }

function json_out($data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** Error with a Bengali + English message. */
function fail(string $bn, string $en, int $code = 400): void {
    json_out(['error' => $bn . ' ' . $en], $code);
}

function body(): array {
    static $b = null;
    if ($b === null) {
        $raw = file_get_contents('php://input') ?: '';
        $b = json_decode($raw, true);
        if (!is_array($b)) $b = [];
    }
    return $b;
}

function str_field(string $key, int $max): string {
    $v = body()[$key] ?? '';
    if (!is_string($v) && !is_numeric($v)) return '';
    $v = trim((string)$v);
    return mb_substr($v, 0, $max);
}

/* ---------------- session & auth ---------------- */

function start_session(): void {
    $cfg = config();
    session_name('wbla_sess');
    session_set_cookie_params([
        'lifetime' => (int)($cfg['session_lifetime'] ?? 604800),
        'path'     => '/',
        'secure'   => (bool)($cfg['https'] ?? false),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
}

function require_csrf(): void {
    $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($sent) || !hash_equals($_SESSION['csrf'] ?? '', $sent)) {
        fail('নিরাপত্তা যাচাই ব্যর্থ, পেজটি রিলোড করুন।', 'Security check failed — reload the page.', 403);
    }
}

function current_user(): ?array {
    static $u = false;
    if ($u !== false) return $u;
    $id = $_SESSION['uid'] ?? null;
    $u = $id ? (q('SELECT * FROM users WHERE id = ?', [$id])->fetch() ?: null) : null;
    return $u;
}

/** Officers count as officers only after approval. */
function effective_role(?array $u): string {
    if (!$u) return 'guest';
    if ($u['role'] === 'officer') return $u['officer_status'] === 'approved' ? 'officer' : 'public';
    return $u['role'];
}

function is_staff(?array $u): bool { return in_array(effective_role($u), ['officer', 'admin'], true); }

function require_login(): array {
    $u = current_user();
    if (!$u) fail('আগে সাইন ইন করুন।', 'Please sign in first.', 401);
    return $u;
}

function require_admin(): array {
    $u = require_login();
    if ($u['role'] !== 'admin') fail('শুধু অ্যাডমিন এটি করতে পারেন।', 'Only the administrator can do this.', 403);
    return $u;
}

function public_user(?array $u): ?array {
    if (!$u) return null;
    return [
        'id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email'], 'mobile' => $u['mobile'],
        'role' => $u['role'], 'officer_status' => $u['officer_status'],
        'district' => $u['district'], 'org' => $u['org'], 'created_at' => iso($u['created_at']),
    ];
}

function client_ip(): string { return substr($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', 0, 45); }
