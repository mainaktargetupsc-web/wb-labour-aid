<?php
/*
 * WB Labour Aid — JSON API.  Every request: api.php?a=<action>
 * Reads use GET; changes use POST with a JSON body and the X-CSRF-Token header.
 */
declare(strict_types=1);

// Path to the app/ folder. Keep app/ OUTSIDE the public web root where possible.
$APP_DIR = __DIR__ . '/../app';
require $APP_DIR . '/lib.php';

set_exception_handler(function (Throwable $e) {
    error_log('[wblabouraid] ' . $e->getMessage());
    json_out(['error' => 'সার্ভারে সমস্যা হয়েছে, পরে আবার চেষ্টা করুন। Server error — please try again later.'], 500);
});

start_session();
$a = $_GET['a'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'POST') require_csrf();
elseif ($method !== 'GET') fail('অনুমোদিত নয়।', 'Method not allowed.', 405);

$posts = ['register','login','logout','profile','password','order_add','order_delete','post_add','post_delete','training_set','admin_status','admin_reset'];
if (in_array($a, $posts, true) && $method !== 'POST') fail('POST প্রয়োজন।', 'POST required.', 405);

switch ($a) {

/* ---------- session ---------- */
case 'me': {
    $u = current_user();
    json_out(['user' => public_user($u), 'role' => effective_role($u), 'csrf' => $_SESSION['csrf']]);
}

case 'register': {
    $name = str_field('name', 120);
    $email = strtolower(str_field('email', 190));
    $mobile = str_field('mobile', 10);
    $pass = (string)(body()['password'] ?? '');
    $role = in_array(body()['role'] ?? '', ROLES_SELF, true) ? body()['role'] : 'public';
    $district = str_field('district', 60);
    $org = str_field('org', 160);

    if ($name === '') fail('পুরো নাম লিখুন।', 'Enter your full name.');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('সঠিক ইমেল লিখুন।', 'Enter a valid email address.');
    if (!preg_match('/^[6-9]\d{9}$/', $mobile)) fail('সঠিক ১০ অঙ্কের মোবাইল নম্বর লিখুন।', 'Enter a valid 10-digit mobile number.');
    if (strlen($pass) < 8) fail('পাসওয়ার্ড অন্তত ৮ অক্ষরের হতে হবে।', 'Password must be at least 8 characters.');
    if (in_array($role, ['hr', 'officer'], true) && $org === '') fail('কোম্পানি বা অফিসের নাম লিখুন।', 'Enter your company or office name.');
    if (q('SELECT 1 FROM users WHERE email = ?', [$email])->fetchColumn()) fail('এই ইমেলে আগেই অ্যাকাউন্ট আছে — সাইন ইন করুন।', 'An account with this email already exists — sign in instead.', 409);

    q('INSERT INTO users (name, email, mobile, password_hash, role, officer_status, district, org, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [$name, $email, $mobile, password_hash($pass, PASSWORD_DEFAULT), $role, $role === 'officer' ? 'pending' : null, $district, $org, now()]);
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)db()->lastInsertId();
    $u = q('SELECT * FROM users WHERE id = ?', [$_SESSION['uid']])->fetch();
    json_out(['user' => public_user($u), 'role' => effective_role($u), 'csrf' => $_SESSION['csrf']]);
}

case 'login': {
    $ip = client_ip();
    $since = gmdate('Y-m-d H:i:s', time() - 900);
    q('DELETE FROM login_attempts WHERE at < ?', [gmdate('Y-m-d H:i:s', time() - 86400)]);
    if ((int)q('SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND at > ?', [$ip, $since])->fetchColumn() >= 10) {
        fail('অনেকবার ভুল চেষ্টা হয়েছে, ১৫ মিনিট পরে আবার চেষ্টা করুন।', 'Too many failed attempts — try again in 15 minutes.', 429);
    }
    $login = strtolower(str_field('login', 190));
    $pass = (string)(body()['password'] ?? '');
    $u = q('SELECT * FROM users WHERE email = ? OR mobile = ?', [$login, $login])->fetch();
    if (!$u || !password_verify($pass, $u['password_hash'])) {
        q('INSERT INTO login_attempts (ip, at) VALUES (?, ?)', [$ip, now()]);
        fail('ইমেল/মোবাইল বা পাসওয়ার্ড মিলছে না।', 'Email/mobile or password is incorrect.', 401);
    }
    if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
        q('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($pass, PASSWORD_DEFAULT), $u['id']]);
    }
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    json_out(['user' => public_user($u), 'role' => effective_role($u), 'csrf' => $_SESSION['csrf']]);
}

case 'logout': {
    $_SESSION = [];
    session_regenerate_id(true);
    $_SESSION['csrf'] = bin2hex(random_bytes(24));
    json_out(['ok' => true, 'csrf' => $_SESSION['csrf']]);
}

case 'profile': {
    $u = require_login();
    $name = str_field('name', 120);
    $mobile = str_field('mobile', 10);
    $district = str_field('district', 60);
    $org = str_field('org', 160);
    if ($name === '') fail('পুরো নাম লিখুন।', 'Enter your full name.');
    if (!preg_match('/^[6-9]\d{9}$/', $mobile)) fail('সঠিক ১০ অঙ্কের মোবাইল নম্বর লিখুন।', 'Enter a valid 10-digit mobile number.');

    $role = $u['role']; $status = $u['officer_status'];
    if ($u['role'] !== 'admin') {
        $role = in_array(body()['role'] ?? '', ROLES_SELF, true) ? body()['role'] : $u['role'];
        if ($role === 'officer') $status = ($u['role'] === 'officer' && $u['officer_status']) ? $u['officer_status'] : 'pending';
        else $status = null;
    }
    if (in_array($role, ['hr', 'officer'], true) && $org === '') fail('কোম্পানি বা অফিসের নাম লিখুন।', 'Enter your company or office name.');
    q('UPDATE users SET name=?, mobile=?, role=?, officer_status=?, district=?, org=? WHERE id=?', [$name, $mobile, $role, $status, $district, $org, $u['id']]);
    $u = q('SELECT * FROM users WHERE id = ?', [$u['id']])->fetch();
    json_out(['user' => public_user($u), 'role' => effective_role($u)]);
}

case 'password': {
    $u = require_login();
    $old = (string)(body()['old'] ?? ''); $new = (string)(body()['new'] ?? '');
    if (!password_verify($old, $u['password_hash'])) fail('বর্তমান পাসওয়ার্ড ভুল।', 'Current password is incorrect.', 401);
    if (strlen($new) < 8) fail('নতুন পাসওয়ার্ড অন্তত ৮ অক্ষরের হতে হবে।', 'New password must be at least 8 characters.');
    q('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $u['id']]);
    json_out(['ok' => true]);
}

/* ---------- govt orders ---------- */
case 'orders': {
    $rows = q('SELECT id, kind, title, body, link, created_by_name, created_at FROM orders ORDER BY created_at DESC, id DESC LIMIT 300')->fetchAll();
    foreach ($rows as &$r) { $r['id'] = (int)$r['id']; $r['created_at'] = iso($r['created_at']); }
    json_out($rows);
}

case 'order_add': {
    $u = require_login();
    if (!is_staff($u)) fail('শুধু অনুমোদিত শ্রম আধিকারিক আদেশ পোস্ট করতে পারেন।', 'Only approved Labour Officers can post orders.', 403);
    $title = str_field('title', 300);
    $kind = in_array(body()['kind'] ?? '', ORDER_KINDS, true) ? body()['kind'] : 'Notification';
    $link = str_field('link', 500);
    if ($title === '') fail('শিরোনাম লিখুন।', 'Enter a title.');
    if ($link !== '' && !preg_match('#^https?://#i', $link)) fail('লিংক http:// বা https:// দিয়ে শুরু হতে হবে।', 'Link must start with http:// or https://');
    q('INSERT INTO orders (kind, title, body, link, created_by, created_by_name, created_at) VALUES (?,?,?,?,?,?,?)',
      [$kind, $title, str_field('body', 4000), $link ?: null, $u['id'], $u['name'], now()]);
    json_out(['ok' => true, 'id' => (int)db()->lastInsertId()]);
}

case 'order_delete': {
    $u = require_login();
    if (!is_staff($u)) fail('শুধু অনুমোদিত শ্রম আধিকারিক আদেশ সরাতে পারেন।', 'Only approved Labour Officers can remove orders.', 403);
    q('DELETE FROM orders WHERE id = ?', [(int)(body()['id'] ?? 0)]);
    json_out(['ok' => true]);
}

/* ---------- discussions ---------- */
case 'posts': {
    $rows = q('SELECT id, user_id, author_name, author_role, body, created_at FROM posts ORDER BY created_at DESC, id DESC LIMIT 200')->fetchAll();
    $u = current_user(); $staff = is_staff($u);
    $out = [];
    foreach ($rows as $r) {
        $out[] = ['id' => (int)$r['id'], 'author_name' => $r['author_name'], 'author_role' => $r['author_role'], 'body' => $r['body'],
                  'created_at' => iso($r['created_at']), 'can_delete' => $u && ($staff || (int)$r['user_id'] === (int)$u['id'])];
    }
    json_out($out);
}

case 'post_add': {
    $u = require_login();
    $text = str_field('body', 2000);
    if (mb_strlen($text) < 3) fail('প্রশ্ন বা উত্তর লিখুন।', 'Write a question or reply first.');
    $recent = (int)q('SELECT COUNT(*) FROM posts WHERE user_id = ? AND created_at > ?', [$u['id'], gmdate('Y-m-d H:i:s', time() - 60)])->fetchColumn();
    if ($recent >= 5) fail('একটু অপেক্ষা করে আবার পোস্ট করুন।', 'Please wait a moment before posting again.', 429);
    q('INSERT INTO posts (user_id, author_name, author_role, body, created_at) VALUES (?,?,?,?,?)',
      [$u['id'], $u['name'] . ($u['district'] ? ', ' . $u['district'] : ''), effective_role($u), $text, now()]);
    json_out(['ok' => true]);
}

case 'post_delete': {
    $u = require_login();
    $id = (int)(body()['id'] ?? 0);
    $owner = q('SELECT user_id FROM posts WHERE id = ?', [$id])->fetchColumn();
    if ($owner === false) json_out(['ok' => true]);
    if (!is_staff($u) && (int)$owner !== (int)$u['id']) fail('এই পোস্ট সরানোর অনুমতি নেই।', 'You cannot remove this post.', 403);
    q('DELETE FROM posts WHERE id = ?', [$id]);
    json_out(['ok' => true]);
}

/* ---------- training ---------- */
case 'training': {
    $u = require_login();
    json_out(array_map('intval', q('SELECT module FROM training WHERE user_id = ?', [$u['id']])->fetchAll(PDO::FETCH_COLUMN)));
}

case 'training_set': {
    $u = require_login();
    $m = (int)(body()['module'] ?? -1);
    if ($m < 0 || $m >= MAX_TRAINING_MODULES) fail('ভুল মডিউল।', 'Invalid module.');
    q('DELETE FROM training WHERE user_id = ? AND module = ?', [$u['id'], $m]);
    if (!empty(body()['done'])) q('INSERT INTO training (user_id, module, done_at) VALUES (?,?,?)', [$u['id'], $m, now()]);
    json_out(array_map('intval', q('SELECT module FROM training WHERE user_id = ?', [$u['id']])->fetchAll(PDO::FETCH_COLUMN)));
}

/* ---------- administration ---------- */
case 'admin_users': {
    require_admin();
    $rows = q("SELECT * FROM users ORDER BY CASE WHEN officer_status = 'pending' THEN 0 ELSE 1 END, created_at DESC")->fetchAll();
    $counts = ['public' => 0, 'hr' => 0, 'officer' => 0, 'pending' => 0, 'admin' => 0];
    foreach ($rows as $r) { $counts[$r['role']] = ($counts[$r['role']] ?? 0) + 1; if ($r['officer_status'] === 'pending') $counts['pending']++; }
    json_out(['users' => array_map('public_user', $rows), 'counts' => $counts,
              'orders' => (int)q('SELECT COUNT(*) FROM orders')->fetchColumn(), 'posts' => (int)q('SELECT COUNT(*) FROM posts')->fetchColumn()]);
}

case 'admin_status': {
    require_admin();
    $status = body()['status'] ?? '';
    if (!in_array($status, ['approved', 'rejected', 'pending'], true)) fail('ভুল অবস্থা।', 'Invalid status.');
    q("UPDATE users SET officer_status = ? WHERE id = ? AND role = 'officer'", [$status, (int)(body()['id'] ?? 0)]);
    json_out(['ok' => true]);
}

case 'admin_reset': {
    $admin = require_admin();
    $id = (int)(body()['id'] ?? 0);
    if ($id === (int)$admin['id']) fail('নিজের পাসওয়ার্ড "অ্যাকাউন্ট" থেকে বদলান।', 'Change your own password from Account.');
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    $temp = ''; for ($i = 0; $i < 10; $i++) $temp .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    $n = q('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($temp, PASSWORD_DEFAULT), $id])->rowCount();
    if (!$n) fail('ব্যবহারকারী পাওয়া যায়নি।', 'User not found.', 404);
    json_out(['ok' => true, 'temp_password' => $temp]);
}

default:
    fail('অজানা অনুরোধ।', 'Unknown action.', 404);
}
