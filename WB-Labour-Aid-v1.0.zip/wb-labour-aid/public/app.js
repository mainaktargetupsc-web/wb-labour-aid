/* WB Labour Aid — single-page app (works with the PHP API, or in demo mode with on-device data). */
(function () {
"use strict";
const C = window.CONTENT;
const DEMO = !!window.WBLA_DEMO;

/* ---------------- helpers ---------------- */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const EN = t => `<span class="en" lang="en">${esc(t)}</span>`;
const bil = p => `${esc(p[0])}${EN(p[1])}`;
const LB = (bn, en) => `${bn} <span class="en" lang="en">· ${en}</span>`;
const H = (bn, en) => `<div class="sechead"><h2>${bn}</h2><p class="en-t" lang="en">${en}</p></div>`;
const L = (bn, en) => `<p class="lede">${bn}${EN(en)}</p>`;
const blist = items => `<ul class="bil">${items.map(i => `<li>${bil(i)}</li>`).join("")}</ul>`;
const box = b => `<div class="card"><h3>${bil(b[0])}</h3>${blist(b[1])}</div>`;
const distBn = v => { const d = C.districts.find(x => x[0] === v); return d ? d[1] : (v || ""); };
const when = d => { try { return new Date(d).toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" }); } catch (e) { return ""; } };
const ERR_NET = "সংযোগে সমস্যা, আবার চেষ্টা করুন। Connection problem — please try again.";
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
};

/* ---------------- sections & access ---------------- */
const TABS = [
  { id: "home", n: "i", bn: "হোম", t: "Home" },
  { id: "old", n: "ii", bn: "পূর্বতন শ্রম আইন", t: "Erstwhile Labour Laws" },
  { id: "codes", n: "iii", bn: "নতুন শ্রম কোড", t: "New Labour Codes" },
  { id: "training", n: "iv", bn: "প্রশিক্ষণ", t: "Training" },
  { id: "orders", n: "v", bn: "আলোচনা ও সরকারি আদেশ", t: "Discussions & Govt Orders" },
  { id: "forms", n: "vi", bn: "ফর্ম ও রেজিস্টার", t: "Forms & Registers" },
  { id: "guide", n: "vii", bn: "বিধিপালন নির্দেশিকা", t: "Compliance Guidance" },
  { id: "contact", n: "viii", bn: "যোগাযোগ", t: "Contact" },
  { id: "hrresp", n: "ix", bn: "এইচআর-এর দায়িত্ব", t: "HR Responsibilities" },
  { id: "duty", n: "x", bn: "সরকারি আধিকারিকের কর্তব্য", t: "Duties of Govt Officials" },
  { id: "admin", n: "★", bn: "প্রশাসন", t: "Administration" }
];
const PUBLIC_TABS = ["home", "old", "codes", "orders", "contact"];
const ALL10 = TABS.slice(0, 10).map(t => t.id);
const ACCESS = {
  guest: PUBLIC_TABS, public: PUBLIC_TABS,
  hr: ["home", "old", "codes", "training", "orders", "forms", "guide", "contact", "hrresp"],
  officer: ALL10, admin: ALL10.concat("admin")
};
const ROLE = {
  guest: ["অতিথি", "Guest"], public: ["সাধারণ নাগরিক", "Public"], hr: ["এইচআর – কোম্পানি", "HR – Company"],
  officer: ["শ্রম আধিকারিক", "Labour Officer"], admin: ["অ্যাডমিন", "Administrator"]
};
const roleTxt = r => ROLE[r] ? `${ROLE[r][0]} · ${ROLE[r][1]}` : r;
const eff = u => !u ? "guest" : (u.role === "officer" ? (u.officer_status === "approved" ? "officer" : "public") : u.role);

/* ---------------- API: real server ---------------- */
let CSRF = "";
async function realApi(a, data, retried) {
  const post = data !== undefined;
  let r;
  try {
    r = await fetch("api.php?a=" + encodeURIComponent(a), {
      method: post ? "POST" : "GET", credentials: "same-origin",
      headers: post ? { "Content-Type": "application/json", "X-CSRF-Token": CSRF } : {},
      body: post ? JSON.stringify(data) : undefined
    });
  } catch (e) { throw new Error(ERR_NET); }
  let j = null; try { j = await r.json(); } catch (e) { }
  if (r.status === 403 && post && !retried && j && /Security check/.test(j.error || "")) { await realApi("me"); return realApi(a, data, true); }
  if (!r.ok) throw new Error((j && j.error) || ERR_NET);
  if (j && j.csrf) CSRF = j.csrf;
  return j;
}

/* ---------------- API: demo (data kept on this device) ---------------- */
const DKEY = "wbla-demo-v1";
const demoSeed = () => {
  const t = Date.now();
  const iso = m => new Date(t - m * 60000).toISOString();
  return {
    uid: null, next: 100,
    users: [
      { id: 1, name: "ডেমো অ্যাডমিন", email: "admin@demo", mobile: "9800000001", pw: "demo1234", role: "admin", officer_status: null, district: "Kolkata", org: "Labour Department (Demo)", created_at: iso(9000) },
      { id: 2, name: "সুমিতা রায়", email: "officer@demo", mobile: "9800000002", pw: "demo1234", role: "officer", officer_status: "approved", district: "Howrah", org: "Assistant Labour Commissioner, Howrah (Demo)", created_at: iso(8000) },
      { id: 3, name: "রাহুল সেন", email: "hr@demo", mobile: "9800000003", pw: "demo1234", role: "hr", officer_status: null, district: "Hooghly", org: "Demo Industries Pvt Ltd", created_at: iso(7000) },
      { id: 4, name: "মিঠু মণ্ডল", email: "worker@demo", mobile: "9800000004", pw: "demo1234", role: "public", officer_status: null, district: "Nadia", org: "", created_at: iso(6000) },
      { id: 5, name: "প্রদীপ ঘোষ", email: "pending@demo", mobile: "9800000005", pw: "demo1234", role: "officer", officer_status: "pending", district: "Malda", org: "Labour Office, Malda (Demo)", created_at: iso(300) }
    ],
    orders: [
      { id: 1, kind: "Notification", title: "নমুনা: মজুরি কোডের অধীনে খসড়া রাজ্য বিধি — মতামত আহ্বান (Sample)", body: "এটি ডেমোর জন্য একটি নমুনা। This is a sample entry for the demo.", link: null, created_by: 2, created_by_name: "সুমিতা রায়", created_at: iso(2900) },
      { id: 2, kind: "Circular", title: "নমুনা: OSH কোডে একক নিবন্ধনের নির্দেশিকা (Sample)", body: "", link: null, created_by: 2, created_by_name: "সুমিতা রায়", created_at: iso(1500) }
    ],
    posts: [
      { id: 1, user_id: 3, author_name: "রাহুল সেন, Hooghly", author_role: "hr", body: "৫০% মজুরি নিয়মে কি আমাদের পিএফ অংশদান বদলাবে?\nDoes the 50% wage rule change our PF contribution?", created_at: iso(900) },
      { id: 2, user_id: 2, author_name: "সুমিতা রায়, Howrah", author_role: "officer", body: "হ্যাঁ — ভাতা মোট বেতনের ৫০% ছাড়ালে বাড়তি অংশ পিএফ ও গ্র্যাচুইটির হিসাবে মজুরি হিসেবে ধরা হবে।\nYes — allowances above 50% of pay count as wages for PF and gratuity.", created_at: iso(600) }
    ],
    training: {}
  };
};
let D = DEMO ? store.get(DKEY, null) || demoSeed() : null;
const dsave = () => store.set(DKEY, D);
const derr = (bn, en) => { throw new Error(bn + " " + en); };
const dpub = u => u ? { id: u.id, name: u.name, email: u.email, mobile: u.mobile, role: u.role, officer_status: u.officer_status, district: u.district, org: u.org, created_at: u.created_at } : null;
const dme = () => D.users.find(u => u.id === D.uid) || null;
const dneed = () => { const u = dme(); if (!u) derr("আগে সাইন ইন করুন।", "Please sign in first."); return u; };
const dstaff = u => ["officer", "admin"].includes(eff(u));
async function demoApi(a, d) {
  d = d || {};
  const res = (() => {
    switch (a) {
      case "me": { const u = dme(); return { user: dpub(u), role: eff(u) }; }
      case "demo_as": { const u = D.users.find(x => x.email === d.email); D.uid = u ? u.id : null; return { user: dpub(u), role: eff(u) }; }
      case "register": {
        const email = String(d.email || "").trim().toLowerCase();
        if (!String(d.name || "").trim()) derr("পুরো নাম লিখুন।", "Enter your full name.");
        if (!/^\S+@\S+\.\S+$/.test(email)) derr("সঠিক ইমেল লিখুন।", "Enter a valid email address.");
        if (!/^[6-9]\d{9}$/.test(d.mobile || "")) derr("সঠিক ১০ অঙ্কের মোবাইল নম্বর লিখুন।", "Enter a valid 10-digit mobile number.");
        if (String(d.password || "").length < 8) derr("পাসওয়ার্ড অন্তত ৮ অক্ষরের হতে হবে।", "Password must be at least 8 characters.");
        if (["hr", "officer"].includes(d.role) && !String(d.org || "").trim()) derr("কোম্পানি বা অফিসের নাম লিখুন।", "Enter your company or office name.");
        if (D.users.some(u => u.email === email)) derr("এই ইমেলে আগেই অ্যাকাউন্ট আছে — সাইন ইন করুন।", "An account with this email already exists — sign in instead.");
        const role = ["public", "hr", "officer"].includes(d.role) ? d.role : "public";
        const u = { id: ++D.next, name: d.name.trim(), email, mobile: d.mobile, pw: d.password, role, officer_status: role === "officer" ? "pending" : null, district: d.district || "", org: (d.org || "").trim(), created_at: new Date().toISOString() };
        D.users.push(u); D.uid = u.id; return { user: dpub(u), role: eff(u) };
      }
      case "login": {
        const id = String(d.login || "").trim().toLowerCase();
        const u = D.users.find(x => x.email === id || x.mobile === id);
        if (!u || u.pw !== d.password) derr("ইমেল/মোবাইল বা পাসওয়ার্ড মিলছে না।", "Email/mobile or password is incorrect.");
        D.uid = u.id; return { user: dpub(u), role: eff(u) };
      }
      case "logout": D.uid = null; return { ok: true };
      case "profile": {
        const u = dneed();
        if (!String(d.name || "").trim()) derr("পুরো নাম লিখুন।", "Enter your full name.");
        if (!/^[6-9]\d{9}$/.test(d.mobile || "")) derr("সঠিক ১০ অঙ্কের মোবাইল নম্বর লিখুন।", "Enter a valid 10-digit mobile number.");
        if (u.role !== "admin") {
          const role = ["public", "hr", "officer"].includes(d.role) ? d.role : u.role;
          u.officer_status = role === "officer" ? (u.role === "officer" && u.officer_status ? u.officer_status : "pending") : null;
          u.role = role;
        }
        if (["hr", "officer"].includes(u.role) && !String(d.org || "").trim()) derr("কোম্পানি বা অফিসের নাম লিখুন।", "Enter your company or office name.");
        Object.assign(u, { name: d.name.trim(), mobile: d.mobile, district: d.district, org: (d.org || "").trim() });
        return { user: dpub(u), role: eff(u) };
      }
      case "password": {
        const u = dneed();
        if (u.pw !== d.old) derr("বর্তমান পাসওয়ার্ড ভুল।", "Current password is incorrect.");
        if (String(d.new || "").length < 8) derr("নতুন পাসওয়ার্ড অন্তত ৮ অক্ষরের হতে হবে।", "New password must be at least 8 characters.");
        u.pw = d.new; return { ok: true };
      }
      case "orders": return D.orders.slice().sort((x, y) => y.created_at.localeCompare(x.created_at));
      case "order_add": {
        const u = dneed(); if (!dstaff(u)) derr("শুধু অনুমোদিত শ্রম আধিকারিক আদেশ পোস্ট করতে পারেন।", "Only approved Labour Officers can post orders.");
        if (!String(d.title || "").trim()) derr("শিরোনাম লিখুন।", "Enter a title.");
        if (d.link && !/^https?:\/\//i.test(d.link)) derr("লিংক http:// বা https:// দিয়ে শুরু হতে হবে।", "Link must start with http:// or https://");
        D.orders.push({ id: ++D.next, kind: d.kind || "Notification", title: d.title.trim(), body: d.body || "", link: d.link || null, created_by: u.id, created_by_name: u.name, created_at: new Date().toISOString() });
        return { ok: true };
      }
      case "order_delete": { const u = dneed(); if (!dstaff(u)) derr("অনুমতি নেই।", "Not allowed."); D.orders = D.orders.filter(o => o.id !== d.id); return { ok: true }; }
      case "posts": {
        const u = dme();
        return D.posts.slice().sort((x, y) => y.created_at.localeCompare(x.created_at)).map(p => Object.assign({}, p, { can_delete: !!u && (dstaff(u) || p.user_id === u.id) }));
      }
      case "post_add": {
        const u = dneed(); const body = String(d.body || "").trim();
        if (body.length < 3) derr("প্রশ্ন বা উত্তর লিখুন।", "Write a question or reply first.");
        D.posts.push({ id: ++D.next, user_id: u.id, author_name: u.name + (u.district ? ", " + u.district : ""), author_role: eff(u), body, created_at: new Date().toISOString() });
        return { ok: true };
      }
      case "post_delete": {
        const u = dneed(); const p = D.posts.find(x => x.id === d.id);
        if (p && !dstaff(u) && p.user_id !== u.id) derr("এই পোস্ট সরানোর অনুমতি নেই।", "You cannot remove this post.");
        D.posts = D.posts.filter(x => x.id !== d.id); return { ok: true };
      }
      case "training": { const u = dneed(); return D.training[u.id] || []; }
      case "training_set": {
        const u = dneed(); let t = (D.training[u.id] || []).filter(m => m !== d.module);
        if (d.done) t.push(d.module); D.training[u.id] = t; return t;
      }
      case "admin_users": {
        const u = dneed(); if (u.role !== "admin") derr("শুধু অ্যাডমিন এটি করতে পারেন।", "Only the administrator can do this.");
        const counts = { public: 0, hr: 0, officer: 0, admin: 0, pending: 0 };
        D.users.forEach(x => { counts[x.role]++; if (x.officer_status === "pending") counts.pending++; });
        const users = D.users.slice().sort((x, y) => (y.officer_status === "pending") - (x.officer_status === "pending") || y.created_at.localeCompare(x.created_at)).map(dpub);
        return { users, counts, orders: D.orders.length, posts: D.posts.length };
      }
      case "admin_status": {
        const u = dneed(); if (u.role !== "admin") derr("শুধু অ্যাডমিন।", "Admin only.");
        const t = D.users.find(x => x.id === d.id && x.role === "officer"); if (t) t.officer_status = d.status; return { ok: true };
      }
      case "admin_reset": {
        const u = dneed(); if (u.role !== "admin") derr("শুধু অ্যাডমিন।", "Admin only.");
        if (d.id === u.id) derr("নিজের পাসওয়ার্ড \"অ্যাকাউন্ট\" থেকে বদলান।", "Change your own password from Account.");
        const t = D.users.find(x => x.id === d.id); if (!t) derr("ব্যবহারকারী পাওয়া যায়নি।", "User not found.");
        const abc = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"; let p = "";
        for (let i = 0; i < 10; i++) p += abc[Math.floor(Math.random() * abc.length)];
        t.pw = p; return { ok: true, temp_password: p };
      }
      default: derr("অজানা অনুরোধ।", "Unknown action.");
    }
  })();
  dsave();
  return JSON.parse(JSON.stringify(res));
}
const api = DEMO ? demoApi : realApi;

/* ---------------- state & routing ---------------- */
let me = { user: null, role: "guest" };
let tab = "home";
let adminFilter = "pending";
let installEvt = null;
const PAGES = ["login", "register", "account"];

function allowed(id) {
  if (id === "login" || id === "register") return !me.user;
  if (id === "account") return !!me.user;
  return ACCESS[me.role].includes(id);
}
function go(id, push) {
  tab = allowed(id) ? id : (id === "account" ? "login" : "home");
  if (push !== false && location.hash !== "#" + tab) history.pushState(null, "", "#" + tab);
  render(); window.scrollTo(0, 0);
  const b = document.querySelector(`nav.tabs [data-tab="${tab}"]`); if (b) b.scrollIntoView({ inline: "nearest", block: "nearest" });
}

/* ---------------- shell ---------------- */
function renderDemoBar() {
  const el = $("#demobar");
  if (!DEMO) { el.hidden = true; return; }
  document.body.classList.add("is-demo");
  el.hidden = false;
  el.innerHTML = `<div class="wrap"><span><b>ডেমো সংস্করণ</b> — তথ্য শুধু এই ডিভাইসে থাকে। <span lang="en">Demo — data stays on this device.</span></span>
    <span>ভূমিকা বেছে দেখুন / Try as:</span>
    <button type="button" data-as="worker@demo">সাধারণ</button><button type="button" data-as="hr@demo">এইচআর</button><button type="button" data-as="officer@demo">আধিকারিক</button><button type="button" data-as="admin@demo">অ্যাডমিন</button><button type="button" data-as="">অতিথি</button>
    <button type="button" id="demo-reset">রিসেট / Reset</button></div>`;
}
function renderAcct() {
  const el = $("#acct");
  if (!me.user) { el.innerHTML = `<a href="#login" data-go="login"><span class="pair"><span>সাইন ইন</span><span class="en" lang="en">Sign in</span></span></a>`; return; }
  el.innerHTML = `<div class="who" title="${esc(me.user.name)}">${esc(me.user.name)}<small>${roleTxt(me.role)}</small></div><a href="#account" data-go="account"><span class="pair"><span>অ্যাকাউন্ট</span><span class="en" lang="en">Account</span></span></a>`;
}
function renderTabs() {
  $("#tabs").innerHTML = TABS.filter(t => ACCESS[me.role].includes(t.id))
    .map(t => `<button role="tab" type="button" data-go="${t.id}" data-tab="${t.id}" aria-selected="${t.id === tab}"><span class="bn">${t.bn}</span><span class="en" lang="en">${t.t}</span></button>`).join("");
}

/* ---------------- views ---------------- */
function statusNote(u) {
  if (u.role === "officer" && u.officer_status === "pending") return `<div class="note">আপনার শ্রম আধিকারিক নিবন্ধন অনুমোদনের অপেক্ষায় আছে। ততদিন সাধারণ বিভাগগুলি দেখতে পাবেন।${EN("Your Labour Officer registration is awaiting approval. Until then you see the Public sections.")}</div>`;
  if (u.role === "officer" && u.officer_status === "rejected") return `<div class="note">আপনার শ্রম আধিকারিক নিবন্ধন অনুমোদিত হয়নি। ভুল হলে শ্রম দপ্তরে যোগাযোগ করুন।${EN("Your Labour Officer registration was not approved. Contact the Labour Department if this is a mistake.")}</div>`;
  return "";
}
const districtOptions = sel => C.districts.map(d => `<option value="${esc(d[0])}" ${sel === d[0] ? "selected" : ""}>${esc(d[1])} (${esc(d[0])})</option>`).join("");
const roleOptions = sel => ["public", "hr", "officer"].map(r => `<option value="${r}" ${sel === r ? "selected" : ""}>${r === "public" ? "শ্রমিক / সাধারণ নাগরিক · Worker / Public" : roleTxt(r)}</option>`).join("");

const V = {
home() {
  const quick = ACCESS[me.role].filter(i => i !== "home").map(i => { const t = TABS.find(x => x.id === i); return `<button type="button" data-go="${i}"><small lang="en">${t.n.toUpperCase()}</small><b>${t.bn}</b><span lang="en">${t.t}</span></button>`; }).join("");
  const u = me.user;
  const reg = !u
    ? `<div class="card stack"><p style="margin:0">বিনামূল্যে নিবন্ধন করুন — শ্রমিক, এইচআর বা শ্রম আধিকারিক হিসেবে। নিবন্ধনের পর আপনার ভূমিকার বিভাগগুলি খুলে যাবে এবং আলোচনায় অংশ নিতে পারবেন।${EN("Register free as a worker, HR professional or Labour Officer to unlock the sections for your role and join discussions.")}</p>
       <div class="btnrow"><a class="btn" href="#register" data-go="register">${LB("নিবন্ধন করুন", "Register")}</a><a class="btn ghost" href="#login" data-go="login">${LB("সাইন ইন", "Sign in")}</a></div></div>`
    : `<div class="card">${statusNote(u)}<div class="row"><div><h3>${esc(u.name)}</h3><div class="meta">${roleTxt(u.role === "officer" ? "officer" : u.role)}${u.org ? " · " + esc(u.org) : ""}${u.district ? " · " + esc(distBn(u.district)) : ""}</div></div><a class="btn ghost sm" href="#account" data-go="account">${LB("তথ্য সম্পাদনা", "Edit details")}</a></div></div>`;
  return `${H(u ? "স্বাগতম, " + esc(u.name.split(" ")[0]) : "স্বাগতম", "Welcome")}
  ${L("শ্রম আইন, চারটি নতুন শ্রম কোড, ফর্ম ও বিধিপালনের তথ্য — পশ্চিমবঙ্গের শ্রমিক, নিয়োগকর্তা ও আধিকারিকদের জন্য এক জায়গায়।", "Labour laws, the four new Labour Codes, forms and compliance help — for workers, employers and officers in West Bengal.")}
  <div class="gallery" id="gal" aria-roledescription="carousel">
    <div class="slide on"><div class="k">Labour reform</div><div class="big">২৯টি কেন্দ্রীয় আইন, এখন ৪টি শ্রম কোড</div><div class="big-en" lang="en">29 central laws, now 4 Labour Codes</div></div>
    <div class="slide"><div class="k">Training</div><div class="big">নিজের সময়মতো শ্রম কোড শিখুন</div><div class="big-en" lang="en">Learn the Labour Codes at your own pace</div></div>
    <div class="slide"><div class="k">Social security</div><div class="big">গিগ ও প্ল্যাটফর্ম কর্মীরা এখন সুরক্ষার আওতায়</div><div class="big-en" lang="en">Gig and platform workers now covered</div></div>
    <div class="dots"><button class="on" type="button" aria-label="স্লাইড ১ / Slide 1"></button><button type="button" aria-label="স্লাইড ২ / Slide 2"></button><button type="button" aria-label="স্লাইড ৩ / Slide 3"></button></div>
  </div>
  ${installEvt ? `<div class="note" style="margin-top:12px"><div class="row"><span>ফোনে অ্যাপ হিসেবে ইনস্টল করুন${EN("Install as an app on your phone")}</span><button class="btn sm" type="button" id="install">${LB("ইনস্টল", "Install")}</button></div></div>` : ""}
  <div class="quick">${quick}</div>
  ${H("নিবন্ধন", "Registration")}
  ${reg}`;
},

login() {
  return `${H("সাইন ইন", "Sign in")}
  <form class="card stack authbox" id="loginf" novalidate>
    ${DEMO ? `<div class="note">ডেমো অ্যাকাউন্ট: officer@demo, hr@demo, worker@demo, admin@demo — পাসওয়ার্ড demo1234${EN("Demo accounts above, password demo1234")}</div>` : ""}
    <div><label class="f" for="l-id">ইমেল বা মোবাইল নম্বর ${EN("Email or mobile number")}</label><input id="l-id" autocomplete="username" required></div>
    <div><label class="f" for="l-pw">পাসওয়ার্ড ${EN("Password")}</label><input id="l-pw" type="password" autocomplete="current-password" required></div>
    <div class="btnrow"><button class="btn" type="submit">${LB("সাইন ইন", "Sign in")}</button><span class="msg" id="l-msg" role="alert"></span></div>
    <p class="meta" style="margin:0">নতুন? <a href="#register" data-go="register">নিবন্ধন করুন</a> · New here? Register.<br>পাসওয়ার্ড ভুলে গেলে শ্রম দপ্তরের অ্যাডমিনের কাছে রিসেট চান। ${EN("Forgot your password? Ask the Labour Department administrator to reset it.")}</p>
  </form>`;
},

register() {
  return `${H("নতুন নিবন্ধন", "Create an account")}
  ${L("সব তথ্য সঠিকভাবে দিন। শ্রম আধিকারিকের অ্যাকাউন্ট অ্যাডমিন যাচাই করে অনুমোদন দিলে তবেই আধিকারিকের বিভাগ খোলে।", "Fill in your details. Labour Officer accounts open after the administrator verifies and approves them.")}
  <form class="card stack" id="regf" novalidate>
    <div class="grid2">
      <div><label class="f" for="r-name">পুরো নাম ${EN("Full name")}</label><input id="r-name" autocomplete="name" required placeholder="যেমন: অনন্যা ঘোষ"></div>
      <div><label class="f" for="r-email">ইমেল ${EN("Email")}</label><input id="r-email" type="email" autocomplete="email" required></div>
      <div><label class="f" for="r-mob">মোবাইল নম্বর ${EN("Mobile number")}</label><input id="r-mob" inputmode="numeric" maxlength="10" autocomplete="tel-national" required placeholder="১০ অঙ্ক / 10 digits"></div>
      <div><label class="f" for="r-pw">পাসওয়ার্ড (অন্তত ৮ অক্ষর) ${EN("Password (min. 8 characters)")}</label><input id="r-pw" type="password" autocomplete="new-password" required></div>
      <div><label class="f" for="r-role">কী হিসেবে নিবন্ধন ${EN("Registering as")}</label><select id="r-role">${roleOptions("public")}</select></div>
      <div><label class="f" for="r-dist">জেলা ${EN("District")}</label><select id="r-dist">${districtOptions("Kolkata")}</select></div>
    </div>
    <div><label class="f" for="r-org">কোম্পানি / অফিস ${EN("Company / Office — required for HR and Officers")}</label><input id="r-org" placeholder="কোম্পানি বা অফিসের নাম"></div>
    <div class="btnrow"><button class="btn" type="submit">${LB("নিবন্ধন করুন", "Register")}</button><span class="msg" id="r-msg" role="alert"></span></div>
    <p class="meta" style="margin:0">আগেই অ্যাকাউন্ট আছে? <a href="#login" data-go="login">সাইন ইন করুন</a> · Already registered? Sign in.</p>
  </form>`;
},

account() {
  const u = me.user;
  return `${H("আমার অ্যাকাউন্ট", "My account")}
  ${statusNote(u)}
  <form class="card stack" id="accf" novalidate>
    <h3>আমার তথ্য${EN("My details")}</h3>
    <div class="grid2">
      <div><label class="f" for="a-name">পুরো নাম ${EN("Full name")}</label><input id="a-name" value="${esc(u.name)}" required></div>
      <div><label class="f" for="a-mob">মোবাইল নম্বর ${EN("Mobile number")}</label><input id="a-mob" inputmode="numeric" maxlength="10" value="${esc(u.mobile)}" required></div>
      ${u.role === "admin" ? "" : `<div><label class="f" for="a-role">ভূমিকা ${EN("Role")}</label><select id="a-role">${roleOptions(u.role)}</select></div>`}
      <div><label class="f" for="a-dist">জেলা ${EN("District")}</label><select id="a-dist">${districtOptions(u.district)}</select></div>
    </div>
    <div><label class="f" for="a-org">কোম্পানি / অফিস ${EN("Company / Office")}</label><input id="a-org" value="${esc(u.org)}"></div>
    <p class="meta" style="margin:0">ইমেল ${EN("Email")}: ${esc(u.email)}</p>
    <div class="btnrow"><button class="btn" type="submit">${LB("সংরক্ষণ করুন", "Save")}</button><span class="msg" id="a-msg" role="status"></span></div>
  </form>
  <form class="card stack" id="pwf" style="margin-top:12px" novalidate>
    <h3>পাসওয়ার্ড বদলান${EN("Change password")}</h3>
    <div class="grid2">
      <div><label class="f" for="p-old">বর্তমান পাসওয়ার্ড ${EN("Current password")}</label><input id="p-old" type="password" autocomplete="current-password"></div>
      <div><label class="f" for="p-new">নতুন পাসওয়ার্ড ${EN("New password")}</label><input id="p-new" type="password" autocomplete="new-password"></div>
    </div>
    <div class="btnrow"><button class="btn" type="submit">${LB("পাসওয়ার্ড বদলান", "Change password")}</button><span class="msg" id="p-msg" role="status"></span></div>
  </form>
  <div style="margin-top:16px"><button class="btn ghost" type="button" id="logout">${LB("সাইন আউট", "Sign out")}</button></div>`;
},

old() {
  return `${H("পূর্বতন শ্রম আইন", "Erstwhile Labour Laws")}
  ${L("শ্রম কোডের আগে যে কেন্দ্রীয় আইনগুলি চালু ছিল, এবং কোন কোড সেগুলির জায়গা নিয়েছে। আইনের সরকারি নাম ইংরেজিতে রাখা হয়েছে।", "The central Acts that applied before the Labour Codes, and the Code that replaces each group. Official Act names are kept in English.")}
  <div class="tbl card"><table><thead><tr><th><span class="bn">নতুন কোড</span>Replaced by</th><th><span class="bn">পূর্বতন আইন</span>Earlier Acts</th><th><span class="bn">সংখ্যা</span>Count</th></tr></thead><tbody>
  ${C.oldLaws.map((acts, i) => `<tr><td><b>${esc(C.codeNames[i][0])}</b><div class="meta" lang="en">${esc(C.codeNames[i][1])}</div></td><td lang="en"><ul>${acts.map(a => `<li>${esc(a)}</li>`).join("")}</ul></td><td class="n">${acts.length}</td></tr>`).join("")}
  </tbody></table></div>
  <p class="meta">মোট ${C.oldLaws.reduce((s, a) => s + a.length, 0)}টি আইন। পশ্চিমবঙ্গ দোকান ও প্রতিষ্ঠান আইন, ১৯৬৩-এর মতো রাজ্য আইন আলাদাভাবে চালু থাকবে।${EN("State Acts such as the WB Shops & Establishments Act, 1963 continue separately.")}</p>`;
},

codes() {
  return `${H("নতুন শ্রম কোড", "New Labour Codes")}
  ${L("চারটি কোড ২৯টি কেন্দ্রীয় আইনকে একত্রিত করেছে। প্রধান পরিবর্তনগুলি নিচে।", "The four Codes consolidate 29 central laws. Key changes below.")}
  <div class="code4">${C.codes.map((pts, i) => `<div class="card"><div class="num">${i + 1}</div><h3>${bil(C.codeNames[i])}</h3>${blist(pts)}</div>`).join("")}</div>
  ${H("সাধারণ প্রশ্ন", "Common questions")}
  <div class="stack">${C.faqs.map(f => `<details><summary>${bil(f[0])}</summary>${esc(f[1][0])}<span class="en-p" lang="en">${esc(f[1][1])}</span></details>`).join("")}</div>`;
},

training() {
  return `${H("শ্রম কোড প্রশিক্ষণ", "Training on the Labour Codes")}
  ${L("প্রতিটি মডিউল পড়ুন এবং শেষ হলে টিক দিন — অগ্রগতি আপনার অ্যাকাউন্টে সংরক্ষিত থাকে।", "Read each module and tick it when done — progress is saved to your account.")}
  <div class="card" style="margin-bottom:12px"><div class="row"><b>${LB("আপনার অগ্রগতি", "Your progress")}</b><span class="meta" id="tp">…</span></div><div class="bar"><i id="tb"></i></div></div>
  <div class="stack">${C.modules.map((m, i) => `<div class="card mod" id="mod${i}"><div class="modhead"><h3><span class="chip n" lang="en">${i + 1}</span> ${bil(m.t)}</h3></div>${blist(m.p)}
    <label class="check" for="m${i}"><input type="checkbox" id="m${i}" data-m="${i}" disabled> শেষ করেছি <span class="en" lang="en">· Mark as done</span></label></div>`).join("")}</div>`;
},

orders() {
  const staff = ["officer", "admin"].includes(me.role);
  return `${H("সরকারি আদেশ ও বিজ্ঞপ্তি", "Govt Orders & Notifications")}
  ${L("শ্রম আধিকারিকদের পোস্ট করা আদেশ, সার্কুলার ও বিজ্ঞপ্তি।", "Orders, circulars and notifications posted by Labour Officers.")}
  ${staff ? `<details><summary>নতুন আদেশ বা বিজ্ঞপ্তি পোস্ট করুন${EN("Post a new order or notification")}</summary><form id="ordf" class="stack" novalidate>
    <div class="grid2"><div><label class="f" for="o-kind">ধরন ${EN("Type")}</label><select id="o-kind">${[["Notification", "বিজ্ঞপ্তি"], ["Order", "আদেশ"], ["Circular", "সার্কুলার"], ["Gazette", "গেজেট"], ["Notice", "নোটিস"]].map(k => `<option value="${k[0]}">${k[1]} · ${k[0]}</option>`).join("")}</select></div>
    <div><label class="f" for="o-link">PDF লিংক (ঐচ্ছিক) ${EN("Link to PDF (optional)")}</label><input id="o-link" type="url" placeholder="https://…"></div></div>
    <div><label class="f" for="o-title">শিরোনাম ${EN("Title")}</label><input id="o-title" required placeholder="যেমন: ন্যূনতম মজুরির সংশোধিত হার — বিজ্ঞপ্তি নং …"></div>
    <div><label class="f" for="o-body">সংক্ষিপ্ত বিবরণ (ঐচ্ছিক) ${EN("Summary (optional)")}</label><textarea id="o-body" rows="3"></textarea></div>
    <div class="btnrow"><button class="btn" type="submit">${LB("প্রকাশ করুন", "Publish")}</button><span class="msg" id="o-msg" role="status"></span></div></form></details>` : ""}
  <div class="card" style="margin-top:12px"><div id="olist"><p class="empty">…</p></div></div>
  ${H("আলোচনা", "Discussions")}
  ${L("শ্রম কোড নিয়ে প্রশ্ন করুন। আধিকারিক ও এইচআর পেশাদাররা উত্তর দেবেন।", "Ask questions about the Labour Codes. Officers and HR professionals reply.")}
  <div class="card">
    ${me.user ? `<form id="postf" class="stack" style="margin-bottom:6px" novalidate><label class="f" for="ptxt">আপনার প্রশ্ন বা উত্তর ${EN("Your question or reply")}</label><textarea id="ptxt" rows="3"></textarea><div class="btnrow"><button class="btn" type="submit">${LB("পোস্ট করুন", "Post")}</button><span class="msg" id="p2-msg" role="status"></span></div></form>`
      : `<p class="meta">পোস্ট করতে <a href="#login" data-go="login">সাইন ইন</a> বা <a href="#register" data-go="register">নিবন্ধন</a> করুন। ${EN("Sign in or register to post.")}</p>`}
    <div id="posts"><p class="empty">…</p></div></div>`;
},

forms() {
  return `${H("ফর্ম ও রেজিস্টার", "Forms & Registers")}
  <div class="note">পশ্চিমবঙ্গের বিধি বিজ্ঞাপিত হলে সরকারি ফর্ম্যাট এখানে যোগ করা হবে। সর্বশেষ তথ্যের জন্য “সরকারি আদেশ” দেখুন।${EN("Official formats will be added here once the West Bengal Rules are notified. See Govt Orders for the latest.")}</div>
  <div class="tbl card"><table><thead><tr><th><span class="bn">কোড</span>Code</th><th><span class="bn">ফর্ম / রেজিস্টার</span>Form / Register</th></tr></thead><tbody>
  ${C.forms.map(f => `<tr><td><span class="chip">${esc(f[0][0])}${f[0][0] !== f[0][1] ? " · " + esc(f[0][1]) : ""}</span></td><td>${bil(f[1]).replace('class="en"', 'class="en meta" style="display:block"')}</td></tr>`).join("")}
  </tbody></table></div>`;
},

guide() {
  return `${H("বিধিপালন নির্দেশিকা", "Compliance Guidance")}
  ${L("নিয়োগকর্তাদের জন্য বিধিপালনের তালিকা। সঠিক সীমা পশ্চিমবঙ্গের বিধির উপর নির্ভর করে।", "A working checklist for employers. Exact thresholds depend on the West Bengal Rules.")}
  <div class="grid2">${C.guide.map(box).join("")}</div>`;
},

contact() {
  const k = C.contact;
  return `${H("যোগাযোগ", "Contact")}
  <div class="grid2">
    <div class="card"><h3>${bil(k.office)}</h3><p lang="en" style="margin:4px 0 8px">${esc(k.address)}</p>
      <div class="row"><span>ওয়েবসাইট ${EN("Website")}: <b id="c1" lang="en">${esc(k.website)}</b></span><button class="copy" data-copy="c1" type="button">কপি · Copy</button></div>
      ${k.helpline ? `<div class="row" style="margin-top:6px"><span>হেল্পলাইন ${EN("Helpline")}: <b id="c2" lang="en">${esc(k.helpline)}</b></span><button class="copy" data-copy="c2" type="button">কপি · Copy</button></div>` : ""}</div>
    <div class="card"><h3>জেলা শ্রম দপ্তর${EN("District Labour Office")}</h3><p style="margin:0">শ্রম দপ্তরের ওয়েবসাইটে আপনার জেলার অফিস খুঁজুন, বা স্থানীয় সহকারী শ্রম কমিশনারের অফিসে যান।${EN("Find your district office on the Labour Department website, or visit your local Assistant Labour Commissioner.")}</p></div>
  </div>`;
},

hrresp() {
  return `${H("এইচআর-এর দায়িত্ব", "Responsibilities of HR")}
  ${L("শ্রম কোড অনুযায়ী কোম্পানির এইচআর-এর করণীয়।", "What HR in a company must do under the Labour Codes.")}
  <div class="grid2">${C.hr.map(box).join("")}</div>`;
},

duty() {
  return `${H("সরকারি আধিকারিকের কর্তব্য ও দায়িত্ব", "Duties & Responsibilities of Govt Officials")}
  ${L("কোড অনুযায়ী পরিদর্শক-সহ-সহায়ক ও অন্যান্য আধিকারিকের ভূমিকা।", "Role of the Inspector-cum-Facilitator and other officers under the Codes.")}
  <div class="grid2">${C.duty.map(box).join("")}</div>`;
},

admin() {
  return `${H("প্রশাসন", "Administration")}
  ${L("শ্রম আধিকারিকের নিবন্ধন যাচাই ও অনুমোদন করুন। শুধু যাচাই করা সরকারি আধিকারিকদের অনুমোদন দিন।", "Verify and approve Labour Officer registrations. Approve only verified government officials.")}
  <div id="adm"><p class="empty">…</p></div>`;
}
};

/* ---------------- dynamic parts ---------------- */
function msg(id, text, ok) { const m = $(id); if (m) { m.className = "msg " + (ok ? "ok" : "err"); m.textContent = text; } }
function twoTap(btn, fn) {
  let armed = false;
  btn.addEventListener("click", async () => {
    if (!armed) { armed = true; btn.dataset.label = btn.innerHTML; btn.innerHTML = "আবার চাপুন · Tap again"; setTimeout(() => { if (armed) { armed = false; btn.innerHTML = btn.dataset.label; } }, 4000); return; }
    armed = false; btn.disabled = true;
    try { await fn(); } catch (e) { btn.disabled = false; btn.textContent = e.message; }
  });
}
const KIND_BN = { Notification: "বিজ্ঞপ্তি", Order: "আদেশ", Circular: "সার্কুলার", Gazette: "গেজেট", Notice: "নোটিস" };

async function loadOrders() {
  const el = $("#olist"); if (!el) return;
  try {
    const rows = await api("orders"); const staff = ["officer", "admin"].includes(me.role);
    el.innerHTML = rows.length ? rows.map(o => `<div class="post"><div class="row"><div><span class="chip">${esc(KIND_BN[o.kind] || o.kind)} · ${esc(o.kind)}</span> <b>${esc(o.title)}</b>${o.body ? `<div class="txt">${esc(o.body)}</div>` : ""}<div class="meta">${when(o.created_at)}${o.created_by_name ? " · " + esc(o.created_by_name) : ""}</div></div>
      <div class="btnrow">${o.link ? `<a class="btn ghost sm" href="${esc(o.link)}" target="_blank" rel="noopener noreferrer">${LB("খুলুন", "Open")}</a>` : ""}${staff ? `<button class="btn ghost sm" type="button" data-odel="${o.id}">${LB("সরান", "Remove")}</button>` : ""}</div></div></div>`).join("")
      : `<p class="empty">এখনও কোনো আদেশ পোস্ট করা হয়নি।${EN(staff ? "No orders yet — use “Post a new order” above." : "No orders posted yet. Labour Officers will post them here.")}</p>`;
    $$("[data-odel]").forEach(b => twoTap(b, async () => { await api("order_delete", { id: +b.dataset.odel }); loadOrders(); }));
  } catch (e) { el.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
}
async function loadPosts() {
  const el = $("#posts"); if (!el) return;
  try {
    const rows = await api("posts");
    el.innerHTML = rows.length ? rows.map(p => `<div class="post"><div class="row"><div class="meta">${esc(p.author_name)} · <span class="chip ${p.author_role === "officer" || p.author_role === "admin" ? "ok" : "n"}">${esc(ROLE[p.author_role] ? ROLE[p.author_role][0] : p.author_role)}</span> · ${when(p.created_at)}</div>${p.can_delete ? `<button class="linkbtn meta" type="button" data-pdel="${p.id}">সরান · Remove</button>` : ""}</div><div class="txt">${esc(p.body)}</div></div>`).join("")
      : `<p class="empty">এখনও কোনো আলোচনা নেই — প্রথম প্রশ্নটি করুন।${EN("No discussions yet. Ask the first question.")}</p>`;
    $$("[data-pdel]").forEach(b => twoTap(b, async () => { await api("post_delete", { id: +b.dataset.pdel }); loadPosts(); }));
  } catch (e) { el.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
}
function setProgress(done) {
  const n = C.modules.length, pct = Math.round(done.length / n * 100);
  const tb = $("#tb"), tp = $("#tp"); if (!tb) return;
  tb.style.width = pct + "%"; tp.textContent = `${done.length} / ${n} · ${pct}%`;
  $$("[data-m]").forEach(c => { const on = done.includes(+c.dataset.m); c.checked = on; c.disabled = false; $("#mod" + c.dataset.m).classList.toggle("done", on); });
}
async function loadAdmin() {
  const el = $("#adm"); if (!el) return;
  try {
    const d = await api("admin_users"); const c = d.counts;
    const F = [["pending", "অপেক্ষমাণ", "Pending"], ["officer", "আধিকারিক", "Officers"], ["hr", "এইচআর", "HR"], ["public", "সাধারণ", "Public"], ["all", "সবাই", "All"]];
    const list = d.users.filter(u => adminFilter === "all" ? true : adminFilter === "pending" ? u.officer_status === "pending" : u.role === adminFilter);
    const statusChip = u => u.role !== "officer" ? "" : u.officer_status === "approved" ? `<span class="chip ok">অনুমোদিত · Approved</span>` : u.officer_status === "rejected" ? `<span class="chip n">অননুমোদিত · Not approved</span>` : `<span class="chip">অপেক্ষমাণ · Pending</span>`;
    el.innerHTML = `<div class="tiles">
        <div class="tile ${c.pending ? "alert" : ""}"><b>${c.pending}</b>অপেক্ষমাণ আধিকারিক${EN("Officers awaiting approval")}</div>
        <div class="tile"><b>${d.users.length}</b>মোট ব্যবহারকারী${EN("Total users")}</div>
        <div class="tile"><b>${c.hr}</b>এইচআর${EN("HR")}</div>
        <div class="tile"><b>${c.public}</b>সাধারণ${EN("Public")}</div>
        <div class="tile"><b>${d.orders}</b>আদেশ${EN("Orders")}</div>
        <div class="tile"><b>${d.posts}</b>আলোচনা${EN("Posts")}</div></div>
      <div class="filters" role="group" aria-label="ফিল্টার / Filter">${F.map(f => `<button type="button" data-f="${f[0]}" aria-pressed="${adminFilter === f[0]}">${f[1]} · ${f[2]}</button>`).join("")}</div>
      <div class="card">${list.length ? list.map(u => `<div class="post" id="u${u.id}"><div class="row"><div><b>${esc(u.name)}</b> <span class="chip n">${esc(ROLE[u.role][0])}</span> ${statusChip(u)}
          <div class="meta">${esc(u.org || "—")} · ${esc(distBn(u.district))}</div><div class="meta" lang="en">${esc(u.email)} · ${esc(u.mobile)} · ${when(u.created_at)}</div><div class="tempwrap"></div></div>
        <div class="btnrow">${u.role === "officer" && u.officer_status !== "approved" ? `<button class="btn sm" type="button" data-st="approved" data-id="${u.id}">${LB("অনুমোদন", "Approve")}</button>` : ""}
          ${u.role === "officer" && u.officer_status !== "rejected" ? `<button class="btn ghost sm" type="button" data-st="rejected" data-id="${u.id}">${u.officer_status === "approved" ? LB("প্রত্যাহার", "Revoke") : LB("বাতিল", "Reject")}</button>` : ""}
          ${u.role !== "admin" ? `<button class="btn ghost sm" type="button" data-reset="${u.id}">${LB("পাসওয়ার্ড রিসেট", "Reset password")}</button>` : ""}</div></div></div>`).join("")
        : `<p class="empty">এই তালিকায় কেউ নেই।${EN("Nobody in this list.")}</p>`}</div>`;
    $$("[data-f]").forEach(b => b.onclick = () => { adminFilter = b.dataset.f; loadAdmin(); });
    $$("[data-st]").forEach(b => b.onclick = async () => { b.disabled = true; try { await api("admin_status", { id: +b.dataset.id, status: b.dataset.st }); loadAdmin(); } catch (e) { b.disabled = false; b.textContent = e.message; } });
    $$("[data-reset]").forEach(b => twoTap(b, async () => {
      const r = await api("admin_reset", { id: +b.dataset.reset });
      const w = document.querySelector(`#u${b.dataset.reset} .tempwrap`);
      w.innerHTML = `<div class="note" style="margin:8px 0 0">নতুন অস্থায়ী পাসওয়ার্ড: <span class="temp" id="tp${b.dataset.reset}">${esc(r.temp_password)}</span> <button class="copy" type="button" data-copy="tp${b.dataset.reset}">কপি · Copy</button>${EN("Give this temporary password to the user privately and ask them to change it from Account.")}</div>`;
      b.remove(); bindCopy();
    }));
  } catch (e) { el.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
}
function bindCopy() {
  $$("[data-copy]").forEach(b => b.onclick = () => {
    const src = document.getElementById(b.dataset.copy); const t = src.textContent;
    const sel = () => { const r = document.createRange(); r.selectNodeContents(src); const s = getSelection(); s.removeAllRanges(); s.addRange(r); };
    if (navigator.clipboard) navigator.clipboard.writeText(t).then(() => b.textContent = "কপি হয়েছে · Copied", sel); else sel();
  });
}

/* ---------------- render & bind ---------------- */
let galTimer;
function render() {
  if (!allowed(tab)) tab = "home";
  renderAcct(); renderTabs();
  $("#main").innerHTML = V[tab]();
  document.title = (TABS.find(t => t.id === tab) ? TABS.find(t => t.id === tab).bn + " · " : "") + "WB Labour Aid";
  bind();
}
function vals(map) { const o = {}; for (const k in map) { const el = $(map[k]); o[k] = el ? el.value : ""; } return o; }
async function submitWith(form, msgId, fn) {
  const b = form.querySelector("button[type=submit]"); b.disabled = true; msg(msgId, "");
  try { await fn(); } catch (e) { msg(msgId, e.message, false); } finally { b.disabled = false; }
}
function bind() {
  clearInterval(galTimer);
  const gal = $("#gal");
  if (gal) {
    const s = gal.querySelectorAll(".slide"), d = gal.querySelectorAll(".dots button"); let i = 0;
    const show = n => { i = n; s.forEach((x, k) => x.classList.toggle("on", k === n)); d.forEach((x, k) => x.classList.toggle("on", k === n)); };
    d.forEach((x, k) => x.onclick = () => { show(k); clearInterval(galTimer); });
    if (!matchMedia("(prefers-reduced-motion: reduce)").matches) galTimer = setInterval(() => show((i + 1) % s.length), 6000);
  }
  const ins = $("#install"); if (ins) ins.onclick = async () => { installEvt.prompt(); await installEvt.userChoice.catch(() => { }); installEvt = null; render(); };

  const lf = $("#loginf");
  if (lf) lf.onsubmit = e => { e.preventDefault(); submitWith(lf, "#l-msg", async () => { me = await api("login", { login: $("#l-id").value, password: $("#l-pw").value }); go("home"); }); };
  const rf = $("#regf");
  if (rf) rf.onsubmit = e => { e.preventDefault(); submitWith(rf, "#r-msg", async () => { me = await api("register", vals({ name: "#r-name", email: "#r-email", mobile: "#r-mob", password: "#r-pw", role: "#r-role", district: "#r-dist", org: "#r-org" })); go("home"); }); };
  const af = $("#accf");
  if (af) af.onsubmit = e => { e.preventDefault(); submitWith(af, "#a-msg", async () => { const r = await api("profile", vals({ name: "#a-name", mobile: "#a-mob", role: "#a-role", district: "#a-dist", org: "#a-org" })); me.user = r.user; me.role = r.role; render(); msg("#a-msg", "সংরক্ষিত হয়েছে · Saved", true); }); };
  const pf = $("#pwf");
  if (pf) pf.onsubmit = e => { e.preventDefault(); submitWith(pf, "#p-msg", async () => { await api("password", { old: $("#p-old").value, new: $("#p-new").value }); pf.reset(); msg("#p-msg", "পাসওয়ার্ড বদলানো হয়েছে · Password changed", true); }); };
  const lo = $("#logout"); if (lo) lo.onclick = async () => { await api("logout", {}).catch(() => { }); me = { user: null, role: "guest" }; go("home"); };

  if (tab === "training") {
    api("training").then(setProgress).catch(e => { $("#tp").textContent = e.message; });
    $$("[data-m]").forEach(c => c.onchange = async () => { c.disabled = true; try { setProgress(await api("training_set", { module: +c.dataset.m, done: c.checked })); } catch (e) { c.checked = !c.checked; c.disabled = false; } });
  }
  if (tab === "orders") {
    loadOrders(); loadPosts();
    const of = $("#ordf");
    if (of) of.onsubmit = e => { e.preventDefault(); submitWith(of, "#o-msg", async () => { await api("order_add", vals({ kind: "#o-kind", title: "#o-title", link: "#o-link", body: "#o-body" })); of.reset(); msg("#o-msg", "প্রকাশিত হয়েছে · Published", true); loadOrders(); }); };
    const ps = $("#postf");
    if (ps) ps.onsubmit = e => { e.preventDefault(); submitWith(ps, "#p2-msg", async () => { await api("post_add", { body: $("#ptxt").value }); ps.reset(); loadPosts(); }); };
  }
  if (tab === "admin") loadAdmin();
  bindCopy();
}

/* ---------------- global events ---------------- */
document.addEventListener("click", e => {
  const g = e.target.closest("[data-go]"); if (g) { e.preventDefault(); go(g.dataset.go); return; }
  const as = e.target.closest("[data-as]");
  if (as) { demoApi("demo_as", { email: as.dataset.as }).then(r => { me = r; adminFilter = "pending"; go(as.dataset.as === "admin@demo" ? "admin" : "home"); }); return; }
  if (e.target.closest("#demo-reset")) { D = demoSeed(); dsave(); me = { user: null, role: "guest" }; go("home"); }
});
window.addEventListener("popstate", () => { const h = location.hash.slice(1) || "home"; if (h !== tab) go(h, false); });
window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); installEvt = e; if (tab === "home") render(); });

// text size (accessibility)
let fs = store.get("wbla-fs", 16);
const applyFs = () => document.documentElement.style.setProperty("--fs", fs + "px");
applyFs();
$("#fs-dec").onclick = () => { fs = Math.max(13, fs - 1); applyFs(); store.set("wbla-fs", fs); };
$("#fs-def").onclick = () => { fs = 16; applyFs(); store.set("wbla-fs", fs); };
$("#fs-inc").onclick = () => { fs = Math.min(22, fs + 1); applyFs(); store.set("wbla-fs", fs); };

if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
  navigator.serviceWorker.register("sw.js").catch(() => { });
}

(async () => {
  renderDemoBar();
  tab = location.hash.slice(1) || "home";
  try { me = await api("me"); } catch (e) { me = { user: null, role: "guest" }; }
  render();
})();
})();
