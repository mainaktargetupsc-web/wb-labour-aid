/*
 * WB Labour Aid — front-end setting.
 * false = use the real server (api.php + database).  true = demo mode (no server; data stays on each device).
 * false = আসল সার্ভার ব্যবহার। true = ডেমো মোড (সার্ভার লাগে না, তথ্য প্রতিটি ডিভাইসে থাকে)।
 */
window.WBLA_DEMO = false;
