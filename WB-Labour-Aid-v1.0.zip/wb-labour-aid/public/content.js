/*
 * WB Labour Aid — reference content (Bengali + English).
 * To update text, edit this file only. Each item is [বাংলা, English].
 * লেখা বদলাতে শুধু এই ফাইলটি সম্পাদনা করুন। প্রতিটি অংশ [বাংলা, English]।
 */
window.CONTENT = {
  codeNames: [
    ["মজুরি কোড, ২০১৯", "Code on Wages, 2019"],
    ["শিল্প সম্পর্ক কোড, ২০২০", "Industrial Relations Code, 2020"],
    ["সামাজিক সুরক্ষা কোড, ২০২০", "Code on Social Security, 2020"],
    ["পেশাগত নিরাপত্তা, স্বাস্থ্য ও কাজের পরিবেশ কোড, ২০২০", "Occupational Safety, Health & Working Conditions Code, 2020"]
  ],

  // Earlier central Acts (official names kept in English), grouped by the Code that replaced them
  oldLaws: [
    ["Payment of Wages Act, 1936", "Minimum Wages Act, 1948", "Payment of Bonus Act, 1965", "Equal Remuneration Act, 1976"],
    ["Trade Unions Act, 1926", "Industrial Employment (Standing Orders) Act, 1946", "Industrial Disputes Act, 1947"],
    ["Employees' Compensation Act, 1923", "Employees' State Insurance Act, 1948", "Employees' Provident Funds & Misc. Provisions Act, 1952", "Employment Exchanges (Compulsory Notification of Vacancies) Act, 1959", "Maternity Benefit Act, 1961", "Payment of Gratuity Act, 1972", "Cine Workers Welfare Fund Act, 1981", "Building & Other Construction Workers' Welfare Cess Act, 1996", "Unorganised Workers' Social Security Act, 2008"],
    ["Factories Act, 1948", "Plantations Labour Act, 1951", "Mines Act, 1952", "Working Journalists and Other Newspaper Employees Act, 1955", "Working Journalists (Fixation of Rates of Wages) Act, 1958", "Motor Transport Workers Act, 1961", "Beedi & Cigar Workers Act, 1966", "Contract Labour (Regulation & Abolition) Act, 1970", "Sales Promotion Employees Act, 1976", "Inter-State Migrant Workmen Act, 1979", "Cine-Workers and Cinema Theatre Workers Act, 1981", "Dock Workers (Safety, Health & Welfare) Act, 1986", "Building & Other Construction Workers Act, 1996"]
  ],

  codes: [
    [["সংগঠিত-অসংগঠিত সব কর্মীর জন্য ন্যূনতম মজুরি", "Minimum wage for all employees, organised or not"],
     ["কেন্দ্র নির্ধারিত জাতীয় ফ্লোর মজুরি", "National floor wage set by the Centre"],
     ["“মজুরি”-র অভিন্ন সংজ্ঞা — বাদ পড়া ভাতা ৫০%-এর বেশি হলে বাড়তি অংশ মজুরিতে যোগ", "Uniform definition of “wages” — excluded allowances above 50% are added back"],
     ["সময়মতো মজুরি প্রদান এবং লিঙ্গ নির্বিশেষে সমান বেতন", "Timely payment and equal pay for all genders"]],
    [["নির্দিষ্ট-মেয়াদি নিয়োগ, স্থায়ী কর্মীর সমান সুবিধাসহ", "Fixed-term employment with the same benefits as permanent staff"],
     ["লে-অফ, ছাঁটাই বা বন্ধের পূর্বানুমতি কেবল ৩০০+ কর্মীর প্রতিষ্ঠানে", "Prior permission for lay-off, retrenchment or closure only at 300+ workers"],
     ["ধর্মঘট বা লক-আউটের আগে ১৪ দিনের নোটিস", "14 days’ notice before a strike or lock-out"],
     ["যৌথ দর-কষাকষির জন্য নেগোশিয়েটিং ইউনিয়ন বা কাউন্সিল", "Negotiating union or council for collective bargaining"]],
    [["গিগ ও প্ল্যাটফর্ম কর্মীদের সামাজিক সুরক্ষা", "Social security for gig and platform workers"],
     ["নির্দিষ্ট-মেয়াদি কর্মীদের ১ বছরেই গ্র্যাচুইটি", "Gratuity after 1 year for fixed-term employees"],
     ["সব জেলায় ইএসআইসি সুবিধার সম্প্রসারণ", "ESIC coverage extended across districts"],
     ["আধার-যুক্ত অসংগঠিত কর্মী নিবন্ধন", "Aadhaar-linked registration of unorganised workers"]],
    [["একক নিবন্ধন, লাইসেন্স ও রিটার্ন", "Single registration, licence and return"],
     ["বাধ্যতামূলক নিয়োগপত্র", "Mandatory appointment letters"],
     ["যোগ্য কর্মীদের বিনামূল্যে বার্ষিক স্বাস্থ্য পরীক্ষা", "Free annual health check-up for eligible workers"],
     ["সম্মতি ও সুরক্ষাসহ মহিলাদের রাতের শিফটে কাজের সুযোগ", "Women may work night shifts with consent and safeguards"]]
  ],

  faqs: [
    [["শ্রম কোড কি পশ্চিমবঙ্গে প্রযোজ্য?", "Do the Codes apply in West Bengal?"],
     ["শ্রম যৌথ তালিকাভুক্ত বিষয়। কোডগুলি সারা দেশে প্রযোজ্য, তবে অনেক বিধান কার্যকর করতে প্রতিটি রাজ্য নিজস্ব বিধি তৈরি করে। পশ্চিমবঙ্গের বিধি ও বিজ্ঞপ্তি “সরকারি আদেশ” বিভাগে দেখুন।", "Labour is a concurrent subject. The Codes apply nationally, but each state frames its own Rules for many provisions. See the West Bengal Rules and notifications under Govt Orders."]],
    [["পরিদর্শক-সহ-সহায়ক কে?", "What is an Inspector-cum-Facilitator?"],
     ["কোডে পুরোনো “ইন্সপেক্টর”-এর জায়গায় পরিদর্শক-সহ-সহায়ক এসেছেন। তিনি পরিদর্শনের পাশাপাশি নিয়োগকর্তা ও কর্মীদের বিধিপালনে পরামর্শ দেন।", "The Codes replace the old “Inspector” with an Inspector-cum-Facilitator, who advises employers and workers on compliance as well as inspecting."]],
    [["নিয়োগপত্র কি এখন বাধ্যতামূলক?", "Is an appointment letter now compulsory?"],
     ["হ্যাঁ। OSH কোড অনুযায়ী যোগদানের সময় প্রত্যেক কর্মীকে নিয়োগপত্র দিতে হবে।", "Yes. Under the OSH Code, every employee must receive an appointment letter on joining."]],
    [["গিগ বা প্ল্যাটফর্ম কর্মী কারা?", "Who is a gig or platform worker?"],
     ["যাঁরা প্রচলিত নিয়োগকর্তা-কর্মী সম্পর্কের বাইরে কাজ করে আয় করেন, প্রায়ই অনলাইন প্ল্যাটফর্মের মাধ্যমে (যেমন ডেলিভারি বা রাইড-শেয়ার)। সামাজিক সুরক্ষা কোডে তাঁদের জন্য কল্যাণ প্রকল্পের ব্যবস্থা আছে।", "Someone who earns outside a traditional employer–employee relationship, often through an online platform (such as delivery or ride-hailing). The Social Security Code provides for welfare schemes for them."]]
  ],

  modules: [
    { t: ["চারটি শ্রম কোডের পরিচিতি", "Overview of the four Labour Codes"], p: [
      ["২৯টি কেন্দ্রীয় শ্রম আইন চারটি কোডে একত্রিত হয়েছে।", "29 central labour laws have been merged into four Codes."],
      ["লক্ষ্য: সহজ বিধিপালন, বেশি কর্মীর সুরক্ষা, এক নিবন্ধন-এক রিটার্ন।", "Aim: simpler compliance, wider worker protection, one registration and one return."],
      ["কেন্দ্র ও রাজ্য দুজনেই নিজ নিজ বিধি তৈরি করে — রাজ্যের বিধি অবশ্যই দেখুন।", "Both the Centre and States frame Rules — always check the State Rules."]]},
    { t: ["মজুরি কোড: মজুরির সংজ্ঞা ও ন্যূনতম মজুরি", "Code on Wages: definition of wages & minimum wage"], p: [
      ["মজুরি = মূল বেতন + মহার্ঘ ভাতা + রিটেনিং ভাতা।", "Wages = basic pay + dearness allowance + retaining allowance."],
      ["বাদ পড়া ভাতাগুলি মোট পারিশ্রমিকের ৫০% ছাড়ালে বাড়তি অংশ মজুরিতে যোগ হয়।", "If excluded allowances exceed 50% of total pay, the excess is added to wages."],
      ["রাজ্যের ন্যূনতম মজুরি জাতীয় ফ্লোর মজুরির কম হতে পারে না।", "A state minimum wage cannot be below the national floor wage."]]},
    { t: ["শিল্প সম্পর্ক কোড: স্থায়ী আদেশ, অভিযোগ কমিটি, নির্দিষ্ট-মেয়াদি নিয়োগ", "IR Code: standing orders, grievance committee, fixed-term employment"], p: [
      ["২০ বা তার বেশি কর্মী থাকলে অভিযোগ নিষ্পত্তি কমিটি গঠন করতে হয়।", "Establishments with 20 or more workers must form a grievance redressal committee."],
      ["৩০০ বা তার বেশি কর্মী থাকলে স্থায়ী আদেশ প্রযোজ্য।", "Standing orders apply at 300 or more workers."],
      ["নির্দিষ্ট-মেয়াদি কর্মীরা একই কাজের স্থায়ী কর্মীর সমান মজুরি ও সুবিধা পান।", "Fixed-term workers get the same wages and benefits as permanent staff doing the same work."]]},
    { t: ["সামাজিক সুরক্ষা: পিএফ, ইএসআই, গ্র্যাচুইটি, গিগ কর্মী", "Social Security: PF, ESI, gratuity, gig workers"], p: [
      ["পিএফ ও ইএসআই-এর অংশদান নির্দিষ্ট সময়ের মধ্যে জমা দিতে হয়।", "PF and ESI contributions must be deposited on time."],
      ["নির্দিষ্ট-মেয়াদি কর্মীরা এক বছর কাজ করলেই গ্র্যাচুইটি পান।", "Fixed-term employees qualify for gratuity after one year."],
      ["গিগ ও প্ল্যাটফর্ম কর্মীদের জন্য সামাজিক সুরক্ষা তহবিলের ব্যবস্থা আছে।", "A social security fund is provided for gig and platform workers."]]},
    { t: ["OSH কোড: নিবন্ধন, লাইসেন্স, স্বাস্থ্য ও নিরাপত্তা", "OSH Code: registration, licences, health & safety"], p: [
      ["প্রতিষ্ঠানের জন্য একটিই নিবন্ধন — আলাদা আলাদা আইনে নিবন্ধনের দরকার নেই।", "One registration per establishment — no separate registrations under different Acts."],
      ["ঠিকাদারদের প্রয়োজনে লাইসেন্স নিতে হয়।", "Contractors obtain a licence where required."],
      ["নির্দিষ্ট সীমার উপরে নিরাপত্তা কমিটি ও বার্ষিক স্বাস্থ্য পরীক্ষা।", "Safety committees and annual health check-ups above set thresholds."]]},
    { t: ["রেজিস্টার, রিটার্ন ও পরিদর্শন প্রক্রিয়া", "Registers, returns and the inspection process"], p: [
      ["রেজিস্টার ইলেকট্রনিক বা কাগজে — দুভাবেই রাখা যায়।", "Registers may be kept electronically or on paper."],
      ["বার্ষিক রিটার্ন অনলাইনে জমা দেওয়া যায়।", "The annual return can be filed online."],
      ["পরিদর্শন হয় ওয়েব-ভিত্তিক, দৈবচয়ন পদ্ধতিতে।", "Inspections follow a web-based, randomised scheme."]]}
  ],

  forms: [
    [["মজুরি", "Wages"], ["মজুরি, কাটছাঁট, জরিমানা ও অগ্রিমের রেজিস্টার", "Register of wages, deductions, fines & advances"]],
    [["মজুরি", "Wages"], ["মজুরি স্লিপ", "Wage slip"]],
    [["OSH", "OSH"], ["প্রতিষ্ঠান নিবন্ধনের আবেদন", "Application for registration of establishment"]],
    [["OSH", "OSH"], ["কর্মচারী / কর্মী রেজিস্টার", "Register of employees / workers"]],
    [["OSH", "OSH"], ["নিয়োগপত্র", "Appointment letter"]],
    [["শিল্প সম্পর্ক", "IR"], ["মডেল স্থায়ী আদেশ", "Model standing orders"]],
    [["সামাজিক সুরক্ষা", "Social Security"], ["দুর্ঘটনা ও বিপজ্জনক ঘটনার রেজিস্টার", "Register of accidents & dangerous occurrences"]],
    [["সামাজিক সুরক্ষা", "Social Security"], ["গ্র্যাচুইটির মনোনয়ন ফর্ম", "Nomination form for gratuity"]],
    [["সব কোড", "All Codes"], ["বার্ষিক রিটার্ন", "Annual return"]]
  ],

  guide: [
    [["নিবন্ধন ও লাইসেন্স", "Registration & licences"], [
      ["OSH কোডে প্রতিষ্ঠানের নিবন্ধন করুন", "Register the establishment under the OSH Code"],
      ["প্রয়োজনে ঠিকাদার লাইসেন্স নেবেন", "Contractors obtain a licence where required"]]],
    [["মজুরি", "Wages"], [
      ["অন্তত বিজ্ঞাপিত ন্যূনতম মজুরি দিন", "Pay at least the notified minimum wage"],
      ["মাসিক মজুরি পরের মাসের ৭ তারিখের মধ্যে দিন", "Pay monthly wages by the 7th of the next month"],
      ["প্রত্যেককে মজুরি স্লিপ দিন", "Issue wage slips to everyone"]]],
    [["নিয়োগ", "Employment"], [
      ["সব কর্মীকে নিয়োগপত্র দিন", "Issue appointment letters to all employees"],
      ["২০+ কর্মী হলে অভিযোগ নিষ্পত্তি কমিটি", "Grievance redressal committee at 20+ workers"],
      ["প্রযোজ্য হলে স্থায়ী আদেশ (৩০০+ কর্মী)", "Standing orders where applicable (300+ workers)"]]],
    [["সামাজিক সুরক্ষা", "Social security"], [
      ["পিএফ ও ইএসআই অংশদান সময়মতো জমা দিন", "Deposit PF and ESI contributions on time"],
      ["গ্র্যাচুইটির মনোনয়ন হালনাগাদ রাখুন", "Keep gratuity nominations up to date"]]],
    [["নিরাপত্তা ও কল্যাণ", "Safety & welfare"], [
      ["প্রয়োজনে বার্ষিক স্বাস্থ্য পরীক্ষা করান", "Arrange annual health check-ups where required"],
      ["সীমা অনুযায়ী নিরাপত্তা কমিটি, ক্যান্টিন ও ক্রেশ", "Safety committee, canteen and crèche as per thresholds"]]],
    [["নথিপত্র", "Records"], [
      ["রেজিস্টার ইলেকট্রনিক বা কাগজে রাখুন", "Maintain registers electronically or on paper"],
      ["বার্ষিক রিটার্ন জমা দিন", "File the annual return"]]]
  ],

  hr: [
    [["নিয়োগের সময়", "On hiring"], [
      ["নিয়োগপত্র দিন", "Issue an appointment letter"],
      ["পিএফ / ইএসআই-তে নাম নথিভুক্ত করুন", "Register the employee for PF / ESI"],
      ["মনোনয়ন নথিভুক্ত করুন", "Record nominations"]]],
    [["প্রতি মাসে", "Every month"], [
      ["সময়মতো মজুরি ও মজুরি স্লিপ দিন", "Pay wages on time, with wage slips"],
      ["পিএফ ও ইএসআই অংশদান জমা দিন", "Deposit PF & ESI contributions"],
      ["মজুরি ও হাজিরা রেজিস্টার হালনাগাদ করুন", "Update wage and attendance registers"]]],
    [["প্রতি বছর", "Every year"], [
      ["বার্ষিক রিটার্ন জমা দিন", "File the annual return"],
      ["প্রয়োজনে স্বাস্থ্য পরীক্ষার ব্যবস্থা করুন", "Arrange health check-ups where required"],
      ["প্রযোজ্য বোনাস দিন", "Pay bonus as applicable"]]],
    [["সবসময়", "Ongoing"], [
      ["অভিযোগ নিষ্পত্তি কমিটি চালু রাখুন", "Run the grievance redressal committee"],
      ["স্থায়ী আদেশ হালনাগাদ রাখুন", "Keep standing orders current"],
      ["পরিদর্শক-সহ-সহায়ককে সহযোগিতা করুন", "Cooperate with the Inspector-cum-Facilitator"]]]
  ],

  duty: [
    [["সহায়তা", "Facilitation"], [
      ["নিয়োগকর্তা ও কর্মীদের বিধিপালনে পরামর্শ দিন", "Advise employers and workers on compliance"],
      ["সচেতনতা ও প্রশিক্ষণ শিবির করুন", "Run awareness and training sessions"]]],
    [["পরিদর্শন", "Inspection"], [
      ["ওয়েব-ভিত্তিক, দৈবচয়িত পরিদর্শন পরিকল্পনা মেনে চলুন", "Follow the web-based, randomised inspection scheme"],
      ["রেজিস্টার ও প্রাঙ্গণ পরীক্ষা করুন", "Examine registers and premises"],
      ["কোড অনুমোদিত ক্ষেত্রে মামলার আগে সংশোধনের সুযোগ দিন", "Give a chance to comply before prosecution where the Code allows"]]],
    [["বিরোধ নিষ্পত্তি", "Dispute resolution"], [
      ["শিল্প বিরোধে আপস-মীমাংসা করুন", "Conciliate industrial disputes"],
      ["মজুরি কোডের দাবির শুনানি করুন", "Hear claims under the Code on Wages"]]],
    [["প্রতিবেদন", "Reporting"], [
      ["পরিদর্শন রিপোর্ট অনলাইনে আপলোড করুন", "Upload inspection reports online"],
      ["শ্রম কমিশনারকে রিপোর্ট দিন", "Report to the Labour Commissioner"]]]
  ],

  // [stored value (English), Bengali label]
  districts: [
    ["Alipurduar","আলিপুরদুয়ার"],["Bankura","বাঁকুড়া"],["Birbhum","বীরভূম"],["Cooch Behar","কোচবিহার"],
    ["Dakshin Dinajpur","দক্ষিণ দিনাজপুর"],["Darjeeling","দার্জিলিং"],["Hooghly","হুগলি"],["Howrah","হাওড়া"],
    ["Jalpaiguri","জলপাইগুড়ি"],["Jhargram","ঝাড়গ্রাম"],["Kalimpong","কালিম্পং"],["Kolkata","কলকাতা"],
    ["Malda","মালদহ"],["Murshidabad","মুর্শিদাবাদ"],["Nadia","নদিয়া"],["North 24 Parganas","উত্তর ২৪ পরগনা"],
    ["Paschim Bardhaman","পশ্চিম বর্ধমান"],["Paschim Medinipur","পশ্চিম মেদিনীপুর"],["Purba Bardhaman","পূর্ব বর্ধমান"],
    ["Purba Medinipur","পূর্ব মেদিনীপুর"],["Purulia","পুরুলিয়া"],["South 24 Parganas","দক্ষিণ ২৪ পরগনা"],["Uttar Dinajpur","উত্তর দিনাজপুর"]
  ],

  contact: {
    office: ["শ্রম দপ্তর, পশ্চিমবঙ্গ সরকার", "Labour Department, Govt. of West Bengal"],
    address: "New Secretariat Buildings, 1 K.S. Roy Road, Kolkata – 700001",
    website: "wblabour.gov.in",
    helpline: "" // add the official helpline number here / সরকারি হেল্পলাইন নম্বর এখানে বসান
  }
};
