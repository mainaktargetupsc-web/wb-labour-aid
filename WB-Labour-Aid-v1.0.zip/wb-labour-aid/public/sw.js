/* WB Labour Aid — service worker: lets the app install on phones and open offline.
   Reference pages work offline; anything from api.php always goes to the network. */
const CACHE = "wbla-v1";
const SHELL = [
  "./", "index.html", "styles.css", "app.js", "content.js", "config.js", "manifest.webmanifest",
  "icons/icon-192.png", "icons/icon-512.png",
  "fonts/hind-siliguri-bengali-400-normal.woff2", "fonts/hind-siliguri-bengali-600-normal.woff2", "fonts/hind-siliguri-bengali-700-normal.woff2",
  "fonts/hind-siliguri-latin-400-normal.woff2", "fonts/hind-siliguri-latin-600-normal.woff2", "fonts/hind-siliguri-latin-700-normal.woff2",
  "fonts/archivo-latin-600-normal.woff2", "fonts/archivo-latin-700-normal.woff2", "fonts/archivo-latin-800-normal.woff2"
];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin || url.pathname.endsWith("api.php")) return;
  // network first (so updates show quickly), fall back to cache when offline
  e.respondWith(fetch(e.request).then(r => {
    if (r.ok) { const copy = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); }
    return r;
  }).catch(() => caches.match(e.request).then(r => r || caches.match("index.html"))));
});
